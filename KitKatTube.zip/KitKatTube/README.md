# KitKatTube (minSdk 19)
فتح المجلد في Android Studio (Flamingo أو أحدث) ثم Build > Build APK.
- بحث + تشغيل muxed (حتى 480p) + HLS كاحتياطي.
- TLS 1.2 مفعّل يدوياً لأندرويد 4.4.
- التالي: تشغيل في الخلفية (Service)، SponsorBlock، DASH لجودات أعلى.
- لو NewPipeExtractor v0.24.2 فشل في البناء: جرّب v0.22.7 أو v0.23.1.
