package com.kitkat.tube;

import androidx.multidex.MultiDexApplication;
import org.schabi.newpipe.extractor.NewPipe;
import org.schabi.newpipe.extractor.localization.ContentCountry;
import org.schabi.newpipe.extractor.localization.Localization;

public class App extends MultiDexApplication {
    @Override public void onCreate() {
        super.onCreate();
        NewPipe.init(new HttpDownloader(), Localization.DEFAULT, ContentCountry.DEFAULT);
    }
}
