package com.kitkat.tube;

import androidx.multidex.MultiDexApplication;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import org.schabi.newpipe.extractor.NewPipe;
import org.schabi.newpipe.extractor.localization.ContentCountry;
import org.schabi.newpipe.extractor.localization.Localization;

public class App extends MultiDexApplication {
    @Override public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                FileWriter fw = new FileWriter(new File(getFilesDir(), "crash.txt"));
                fw.write(sw.toString());
                fw.close();
            } catch (Throwable ignored) { }
            if (old != null) old.uncaughtException(t, e);
        });
        try {
            NewPipe.init(new HttpDownloader(), Localization.DEFAULT, ContentCountry.DEFAULT);
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }
}
