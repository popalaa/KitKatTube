package com.kitkat.tube;

import android.graphics.drawable.GradientDrawable;
import android.widget.TextView;

final class Avatar {
    private static final int[] COLORS = {0xFFE53935, 0xFF8E24AA, 0xFF3949AB, 0xFF00897B,
        0xFFF4511E, 0xFF6D4C41, 0xFF1E88E5, 0xFF7CB342};

    private Avatar() {}

    static void apply(TextView tv, String name) {
        String n = name == null ? "" : name.trim();
        tv.setText(n.isEmpty() ? "?" : n.substring(0, n.offsetByCodePoints(0, 1)).toUpperCase());
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(COLORS[(n.hashCode() & 0x7fffffff) % COLORS.length]);
        tv.setBackgroundDrawable(g);
    }
}
