package com.kitkat.tube;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/** كروت كبيرة زي الصفحة الرئيسية في يوتيوب. */
class CardAdapter extends BaseAdapter {
    interface OnChannel { void open(Row r); }
    final List<Row> items = new ArrayList<>();
    private final LayoutInflater inflater;
    private final Context ctx;
    private final OnChannel onChannel;

    CardAdapter(Context c) { this(c, null); }

    CardAdapter(Context c, OnChannel oc) {
        ctx = c; inflater = LayoutInflater.from(c); onChannel = oc;
    }

    @Override public int getCount() { return items.size(); }
    @Override public Object getItem(int i) { return items.get(i); }
    @Override public long getItemId(int i) { return i; }

    @Override public View getView(int pos, View v, ViewGroup parent) {
        if (v == null) v = inflater.inflate(R.layout.item_card, parent, false);
        Row r = items.get(pos);
        int w = 0;
        if (parent instanceof GridView) w = ((GridView) parent).getColumnWidth();
        if (w <= 0) w = parent.getWidth();
        if (w <= 0) w = 480;
        ImageView thumb = (ImageView) v.findViewById(R.id.thumb);
        thumb.getLayoutParams().height = w * 9 / 16;
        ((TextView) v.findViewById(R.id.title)).setText(r.title);
        StringBuilder sub = new StringBuilder();
        if (r.uploader != null) sub.append(r.uploader);
        if (r.meta != null && !r.meta.isEmpty()) sub.append(" • ").append(r.meta);
        ((TextView) v.findViewById(R.id.sub)).setText(sub);
        TextView av = (TextView) v.findViewById(R.id.avatar);
        Avatar.apply(av, r.uploader);
        final Row rr = r;
        av.setOnClickListener(x -> {
            if (rr.channelUrl == null) return;
            if (onChannel != null) { onChannel.open(rr); return; }
            Intent i = new Intent(ctx, ChannelActivity.class);
            i.putExtra("url", rr.channelUrl);
            i.putExtra("name", rr.uploader);
            ctx.startActivity(i);
        });
        TextView dur = (TextView) v.findViewById(R.id.dur);
        dur.setText(Fmt.duration(r.duration));
        dur.setVisibility(r.duration > 0 ? View.VISIBLE : View.GONE);
        ImageLoader.load(r.thumb, thumb);
        return v;
    }
}
