package com.kitkat.tube;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.AbsListView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.schabi.newpipe.extractor.Image;
import org.schabi.newpipe.extractor.InfoItem;
import org.schabi.newpipe.extractor.ListExtractor;
import org.schabi.newpipe.extractor.ListExtractor.InfoItemsPage;
import org.schabi.newpipe.extractor.Page;
import org.schabi.newpipe.extractor.channel.ChannelInfo;

/** صفحة القناة: صورة واسم ومشتركين وزر اشتراك وفيديوهات القناة. */
public class ChannelActivity extends AppCompatActivity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private CardAdapter adapter;
    private GridView grid;
    private ProgressBar progress;
    private TextView empty, cName, cSubs, cDesc, cLetter, subBtn;
    private ImageView cImg;
    private ListExtractor<? extends InfoItem> extractor;
    private Page nextPage;
    private boolean hasMore, loading, descOpen;
    private String url, name, id, avatar;

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_channel);
        url = getIntent().getStringExtra("url");
        name = getIntent().getStringExtra("name");
        id = Subs.idFromUrl(url);

        grid = findViewById(R.id.grid);
        progress = findViewById(R.id.progress);
        empty = findViewById(R.id.empty);
        cName = findViewById(R.id.cName);
        cSubs = findViewById(R.id.cSubs);
        cDesc = findViewById(R.id.cDesc);
        cLetter = findViewById(R.id.cLetter);
        cImg = findViewById(R.id.cImg);
        subBtn = findViewById(R.id.cSubBtn);

        cName.setText(name == null ? "" : name);
        Avatar.apply(cLetter, name);
        cDesc.setOnClickListener(v -> {
            descOpen = !descOpen;
            cDesc.setMaxLines(descOpen ? 40 : 2);
        });
        subBtn.setOnClickListener(v -> toggleSub());

        adapter = new CardAdapter(this, null);
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((p, v, pos, i) -> {
            Intent in = new Intent(this, PlayerActivity.class);
            in.putExtra("url", adapter.items.get(pos).url);
            startActivity(in);
        });
        grid.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(AbsListView v, int st) { }
            @Override public void onScroll(AbsListView v, int first, int visible, int total) {
                if (total > 0 && first + visible >= total - 3 && hasMore && !loading) loadMore();
            }
        });
        updateSubBtn();
        load();
    }

    private void updateSubBtn() {
        boolean sub = Subs.contains(this, url);
        subBtn.setVisibility(View.VISIBLE);
        subBtn.setText(sub ? "تم الاشتراك" : "اشترك");
        subBtn.setBackgroundResource(sub ? R.drawable.bg_chip : R.drawable.bg_chip_sel);
        subBtn.setTextColor(sub ? 0xFFFFFFFF : 0xFF000000);
    }

    private void toggleSub() {
        if (Subs.contains(this, url)) {
            Subs.remove(this, url);
        } else {
            String cid = id;
            if (cid == null) {
                Toast.makeText(this, "لسه بحمّل بيانات القناة، جرّب كمان لحظة", Toast.LENGTH_SHORT).show();
                return;
            }
            Subs.add(this, new Subs.Chan(cid, url, name == null ? "" : name, avatar));
        }
        updateSubBtn();
    }

    private void load() {
        loading = true;
        io.execute(() -> {
            try {
                ChannelInfo ci = ChannelInfo.getInfo(url);
                final String n = ci.getName();
                final String cid = ci.getId();
                final long subs = ci.getSubscriberCount();
                String d = ci.getDescription();
                final CharSequence desc = d == null || d.isEmpty() ? "" : Html.fromHtml(d);
                String av = null;
                List<Image> imgs = ci.getAvatars();
                for (Image im : imgs) {
                    if (av == null || im.getWidth() > 0 && im.getWidth() <= 200) av = im.getUrl();
                }
                final String avFinal = av;
                ListExtractor<? extends InfoItem> ex = Channels.videos(url);
                InfoItemsPage<? extends InfoItem> p = ex.getInitialPage();
                final List<Row> rows = Channels.rows(p, n, url);
                final Page np = p.getNextPage();
                final boolean more = p.hasNextPage();
                runOnUiThread(() -> {
                    name = n;
                    if (id == null) id = cid;
                    avatar = avFinal;
                    Subs.setAvatar(this, url, avFinal);
                    cName.setText(n);
                    Avatar.apply(cLetter, n);
                    if (avFinal != null) ImageLoader.loadCircle(avFinal, cImg);
                    cSubs.setText(subs >= 0 ? Fmt.subs(subs) : "");
                    if (desc.length() > 0) {
                        cDesc.setText(desc);
                        cDesc.setVisibility(View.VISIBLE);
                    }
                    extractor = ex;
                    nextPage = np;
                    adapter.items.clear();
                    adapter.items.addAll(rows);
                    adapter.notifyDataSetChanged();
                    hasMore = more;
                    loading = false;
                    progress.setVisibility(View.GONE);
                    empty.setText("مفيش فيديوهات");
                    empty.setVisibility(rows.isEmpty() ? View.VISIBLE : View.GONE);
                    updateSubBtn();
                });
            } catch (Throwable e) {
                if (io.isShutdown() || MainActivity.isCancel(e)) return;
                final String tr = MainActivity.trace(e);
                runOnUiThread(() -> {
                    loading = false;
                    progress.setVisibility(View.GONE);
                    new AlertDialog.Builder(this).setTitle("Error")
                        .setMessage(tr).setPositiveButton("OK", null).show();
                });
            }
        });
    }

    private void loadMore() {
        if (extractor == null || nextPage == null) return;
        loading = true;
        final ListExtractor<? extends InfoItem> ex = extractor;
        final Page np = nextPage;
        io.execute(() -> {
            try {
                InfoItemsPage<? extends InfoItem> p = ex.getPage(np);
                final List<Row> rows = Channels.rows(p, name, url);
                final Page nn = p.getNextPage();
                final boolean more = p.hasNextPage();
                runOnUiThread(() -> {
                    nextPage = nn;
                    adapter.items.addAll(rows);
                    adapter.notifyDataSetChanged();
                    hasMore = more;
                    loading = false;
                });
            } catch (Throwable e) {
                runOnUiThread(() -> { hasMore = false; loading = false; });
            }
        });
    }

    @Override protected void onDestroy() { super.onDestroy(); io.shutdownNow(); }
}
