package com.kitkat.tube;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.schabi.newpipe.extractor.InfoItem;
import org.schabi.newpipe.extractor.ListExtractor;
import org.schabi.newpipe.extractor.ListExtractor.InfoItemsPage;
import org.schabi.newpipe.extractor.ServiceList;
import org.schabi.newpipe.extractor.channel.ChannelInfo;
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabExtractor;
import org.schabi.newpipe.extractor.linkhandler.ListLinkHandler;
import org.schabi.newpipe.extractor.stream.StreamInfoItem;

final class Channels {
    private Channels() {}

    static String idFromUrl(String url) {
        if (url == null) return null;
        Matcher m = Pattern.compile("/channel/(UC[\\w-]+)").matcher(url);
        return m.find() ? m.group(1) : null;
    }

    static ChannelTabExtractor videosTab(ChannelInfo ci) throws Exception {
        for (ListLinkHandler h : ci.getTabs()) {
            if (h.getContentFilters().contains("videos")) {
                return ServiceList.YouTube.getChannelTabExtractor(h);
            }
        }
        return ServiceList.YouTube.getChannelTabExtractorFromId(ci.getId(), "videos");
    }

    static ListExtractor<? extends InfoItem> videos(String url) throws Exception {
        String id = idFromUrl(url);
        ChannelTabExtractor ex;
        if (id != null) ex = ServiceList.YouTube.getChannelTabExtractorFromId(id, "videos");
        else ex = videosTab(ChannelInfo.getInfo(url));
        ex.fetchPage();
        return ex;
    }

    /** يحوّل صفحة نتايج لصفوف، ويكمّل اسم القناة ورابطها لو ناقصين. */
    static List<Row> rows(InfoItemsPage<? extends InfoItem> p, String name, String url) {
        List<Row> out = new ArrayList<>();
        for (InfoItem it : p.getItems()) {
            if (!(it instanceof StreamInfoItem)) continue;
            Row r = Row.from((StreamInfoItem) it);
            if ((r.uploader == null || r.uploader.isEmpty()) && name != null) r.uploader = name;
            if (r.channelUrl == null || r.channelUrl.isEmpty()) r.channelUrl = url;
            out.add(r);
        }
        return out;
    }
}
