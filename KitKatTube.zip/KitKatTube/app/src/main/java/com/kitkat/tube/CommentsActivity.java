package com.kitkat.tube;

import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.schabi.newpipe.extractor.ListExtractor;
import org.schabi.newpipe.extractor.ListExtractor.InfoItemsPage;
import org.schabi.newpipe.extractor.Page;
import org.schabi.newpipe.extractor.ServiceList;
import org.schabi.newpipe.extractor.comments.CommentsInfoItem;
import org.schabi.newpipe.extractor.stream.Description;

/** تعليقات الفيديو مع تحميل المزيد عند النزول. */
public class CommentsActivity extends AppCompatActivity {
    static class Cm { String name, date, text, likes; }

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final List<Cm> items = new ArrayList<>();
    private ListExtractor<CommentsInfoItem> extractor;
    private Page nextPage;
    private boolean hasMore, loading;
    private ProgressBar progress;
    private TextView empty;
    private BaseAdapter adapter;

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_comments);
        progress = findViewById(R.id.progress);
        empty = findViewById(R.id.empty);
        ListView list = findViewById(R.id.list);
        final LayoutInflater inf = LayoutInflater.from(this);
        adapter = new BaseAdapter() {
            @Override public int getCount() { return items.size(); }
            @Override public Object getItem(int i) { return items.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int pos, View v, ViewGroup parent) {
                if (v == null) v = inf.inflate(R.layout.item_comment, parent, false);
                Cm c = items.get(pos);
                Avatar.apply((TextView) v.findViewById(R.id.cmAvatar), c.name);
                ((TextView) v.findViewById(R.id.cmHead)).setText(
                    c.date.isEmpty() ? c.name : c.name + " • " + c.date);
                ((TextView) v.findViewById(R.id.cmText)).setText(c.text);
                ((TextView) v.findViewById(R.id.cmLikes)).setText(c.likes);
                return v;
            }
        };
        list.setAdapter(adapter);
        list.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(AbsListView v, int st) { }
            @Override public void onScroll(AbsListView v, int first, int visible, int total) {
                if (total > 0 && first + visible >= total - 3 && hasMore && !loading) loadMore();
            }
        });
        final String url = getIntent().getStringExtra("url");
        loading = true;
        io.execute(() -> {
            try {
                ListExtractor<CommentsInfoItem> ex = ServiceList.YouTube.getCommentsExtractor(url);
                ex.fetchPage();
                InfoItemsPage<CommentsInfoItem> p = ex.getInitialPage();
                final List<Cm> rows = convert(p);
                final Page np = p.getNextPage();
                final boolean more = p.hasNextPage();
                runOnUiThread(() -> {
                    extractor = ex;
                    nextPage = np;
                    items.addAll(rows);
                    adapter.notifyDataSetChanged();
                    hasMore = more;
                    loading = false;
                    progress.setVisibility(View.GONE);
                    if (rows.isEmpty()) {
                        empty.setText("مفيش تعليقات");
                        empty.setVisibility(View.VISIBLE);
                    }
                });
            } catch (Throwable e) {
                runOnUiThread(() -> {
                    loading = false;
                    progress.setVisibility(View.GONE);
                    empty.setText("التعليقات غير متاحة لهذا الفيديو\n" + e.getClass().getSimpleName());
                    empty.setVisibility(View.VISIBLE);
                });
            }
        });
    }

    private void loadMore() {
        if (extractor == null || nextPage == null) return;
        loading = true;
        final ListExtractor<CommentsInfoItem> ex = extractor;
        final Page np = nextPage;
        io.execute(() -> {
            try {
                InfoItemsPage<CommentsInfoItem> p = ex.getPage(np);
                final List<Cm> rows = convert(p);
                final Page nn = p.getNextPage();
                final boolean more = p.hasNextPage();
                runOnUiThread(() -> {
                    nextPage = nn;
                    items.addAll(rows);
                    adapter.notifyDataSetChanged();
                    hasMore = more;
                    loading = false;
                });
            } catch (Throwable e) {
                runOnUiThread(() -> { hasMore = false; loading = false; });
            }
        });
    }

    private static List<Cm> convert(InfoItemsPage<CommentsInfoItem> p) {
        List<Cm> out = new ArrayList<>();
        for (CommentsInfoItem c : p.getItems()) {
            Cm m = new Cm();
            m.name = c.getUploaderName() == null ? "" : c.getUploaderName();
            m.date = c.getTextualUploadDate() == null ? "" : c.getTextualUploadDate();
            Object t = c.getCommentText();
            String raw = t instanceof Description ? ((Description) t).getContent() : String.valueOf(t);
            m.text = raw == null ? "" : Html.fromHtml(raw).toString();
            int likes = c.getLikeCount();
            StringBuilder sb = new StringBuilder();
            if (c.isPinned()) sb.append("مثبّت  ");
            if (likes > 0) sb.append(likes).append(" إعجاب");
            m.likes = sb.toString();
            out.add(m);
        }
        return out;
    }

    @Override protected void onDestroy() { super.onDestroy(); io.shutdownNow(); }
}
