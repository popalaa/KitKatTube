package com.kitkat.tube;

import java.util.Locale;

final class Fmt {
    private Fmt() {}

    static String duration(long s) {
        if (s <= 0) return "";
        long h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        if (h > 0) return String.format(Locale.US, "%d:%02d:%02d", h, m, sec);
        return String.format(Locale.US, "%d:%02d", m, sec);
    }

    static String views(long v) {
        if (v < 0) return "";
        if (v >= 1000000000L) return String.format(Locale.US, "%.1fB views", v / 1e9);
        if (v >= 1000000L) return String.format(Locale.US, "%.1fM views", v / 1e6);
        if (v >= 1000L) return String.format(Locale.US, "%.1fK views", v / 1e3);
        return v + " views";
    }

    static String safeName(String s) {
        String r = s.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return r.length() > 80 ? r.substring(0, 80) : r;
    }
}
