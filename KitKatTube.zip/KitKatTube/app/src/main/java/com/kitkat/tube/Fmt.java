package com.kitkat.tube;

import java.util.Locale;

final class Fmt {
    private Fmt() {}

    static String duration(long s) {
        if (s <= 0) return "";
        long h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        if (h > 0) return String.format(Locale.US, "%d:%02d:%02d", h, m, sec);
        return String.format(Locale.US, "%d:%02d", m, sec);
    }

    static String views(long v) {
        if (v < 0) return "";
        if (v >= 1000000L) return String.format(Locale.US, "%.1f", v / 1e6) + " مليون مشاهدة";
        if (v >= 1000L) return String.format(Locale.US, "%.1f", v / 1e3) + " ألف مشاهدة";
        return v + " مشاهدة";
    }

    static String subs(long v) {
        if (v >= 1000000L) return String.format(Locale.US, "%.1f", v / 1e6) + " مليون مشترك";
        if (v >= 1000L) return String.format(Locale.US, "%.1f", v / 1e3) + " ألف مشترك";
        return v + " مشترك";
    }

    static String ago(long ts) {
        if (ts <= 0) return "";
        long s = (System.currentTimeMillis() - ts) / 1000;
        if (s < 60) return "منذ لحظات";
        long m = s / 60;
        if (m < 60) return "منذ " + m + " دقيقة";
        long h = m / 60;
        if (h < 24) return "منذ " + h + " ساعة";
        long d = h / 24;
        if (d < 30) return "منذ " + d + " يوم";
        if (d < 365) return "منذ " + (d / 30) + " شهر";
        return "منذ " + (d / 365) + " سنة";
    }

    static String safeName(String s) {
        String r = s.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return r.length() > 80 ? r.substring(0, 80) : r;
    }
}
