package com.kitkat.tube;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;

final class History {
    private History() {}

    private static android.content.SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("history", Context.MODE_PRIVATE);
    }

    static synchronized List<Row> load(Context c) {
        List<Row> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs(c).getString("list", "[]"));
            for (int i = 0; i < a.length(); i++) out.add(Row.fromJson(a.getJSONObject(i)));
        } catch (Throwable ignored) { }
        return out;
    }

    static synchronized void add(Context c, Row r) {
        try {
            List<Row> list = load(c);
            for (int i = list.size() - 1; i >= 0; i--) {
                if (r.url != null && r.url.equals(list.get(i).url)) list.remove(i);
            }
            list.add(0, r);
            JSONArray a = new JSONArray();
            for (int i = 0; i < list.size() && i < 150; i++) a.put(list.get(i).toJson());
            prefs(c).edit().putString("list", a.toString()).apply();
        } catch (Throwable ignored) { }
    }

    static synchronized void clear(Context c) {
        prefs(c).edit().remove("list").apply();
    }
}
