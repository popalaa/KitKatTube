package com.kitkat.tube;

import android.os.Build;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import org.schabi.newpipe.extractor.downloader.Downloader;
import org.schabi.newpipe.extractor.downloader.Request;
import org.schabi.newpipe.extractor.downloader.Response;
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException;

public class HttpDownloader extends Downloader {
    private static final String UA =
        "Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0";
    private final OkHttpClient client;
    private static OkHttpClient shared;

    public static OkHttpClient client() { return shared; }

    public HttpDownloader() {
        OkHttpClient.Builder b = new OkHttpClient.Builder()
            .readTimeout(30, TimeUnit.SECONDS)
            .connectTimeout(30, TimeUnit.SECONDS);
        if (Build.VERSION.SDK_INT < 21) {
            try {
                TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
                tmf.init((java.security.KeyStore) null);
                X509TrustManager tm = (X509TrustManager) tmf.getTrustManagers()[0];
                SSLContext sc = SSLContext.getInstance("TLSv1.2");
                sc.init(null, new TrustManager[]{tm}, null);
                b.sslSocketFactory(new Tls12SocketFactory(sc.getSocketFactory()), tm);
            } catch (Exception e) { throw new RuntimeException(e); }
        }
        client = b.build();
        shared = client;
    }

    @Override
    public Response execute(Request request) throws IOException, ReCaptchaException {
        byte[] data = request.dataToSend();
        RequestBody body = data != null ? RequestBody.create(null, data) : null;
        okhttp3.Request.Builder rb = new okhttp3.Request.Builder()
            .method(request.httpMethod(), body)
            .url(request.url())
            .addHeader("User-Agent", UA);
        for (Map.Entry<String, List<String>> e : request.headers().entrySet()) {
            rb.removeHeader(e.getKey());
            for (String v : e.getValue()) rb.addHeader(e.getKey(), v);
        }
        okhttp3.Response r = client.newCall(rb.build()).execute();
        if (r.code() == 429) { r.close(); throw new ReCaptchaException("429", request.url()); }
        String text = r.body() != null ? r.body().string() : "";
        return new Response(r.code(), r.message(), r.headers().toMultimap(), text, r.request().url().toString());
    }
}
