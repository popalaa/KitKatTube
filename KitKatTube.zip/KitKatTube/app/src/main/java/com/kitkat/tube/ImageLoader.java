package com.kitkat.tube;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class ImageLoader {
    interface Callback { void done(Bitmap b); }

    private static final LruCache<String, Bitmap> cache =
        new LruCache<String, Bitmap>(8 * 1024 * 1024) {
            @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
        };
    private static final ExecutorService pool = Executors.newFixedThreadPool(3);
    private static final Handler ui = new Handler(Looper.getMainLooper());

    private ImageLoader() {}

    static Bitmap cached(String url) { return cache.get(url); }

    static void load(final String url, final ImageView iv) {
        iv.setTag(url);
        iv.setImageBitmap(null);
        if (url == null) return;
        Bitmap c = cache.get(url);
        if (c != null) { iv.setImageBitmap(c); return; }
        pool.execute(() -> {
            final Bitmap b = fetch(url, 320);
            if (b == null) return;
            cache.put(url, b);
            ui.post(() -> { if (url.equals(iv.getTag())) iv.setImageBitmap(b); });
        });
    }

    static void loadCircle(final String url, final ImageView iv) {
        iv.setTag(url);
        iv.setImageBitmap(null);
        if (url == null) return;
        final String key = url + "|c";
        Bitmap c = cache.get(key);
        if (c != null) { iv.setImageBitmap(c); return; }
        pool.execute(() -> {
            Bitmap b = fetch(url, 160);
            if (b == null) return;
            final Bitmap round = circle(b);
            cache.put(key, round);
            ui.post(() -> { if (url.equals(iv.getTag())) iv.setImageBitmap(round); });
        });
    }

    private static Bitmap circle(Bitmap src) {
        int size = Math.min(src.getWidth(), src.getHeight());
        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        android.graphics.Canvas cv = new android.graphics.Canvas(out);
        android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        android.graphics.BitmapShader sh = new android.graphics.BitmapShader(src,
            android.graphics.Shader.TileMode.CLAMP, android.graphics.Shader.TileMode.CLAMP);
        android.graphics.Matrix m = new android.graphics.Matrix();
        m.postTranslate(-(src.getWidth() - size) / 2f, -(src.getHeight() - size) / 2f);
        sh.setLocalMatrix(m);
        p.setShader(sh);
        cv.drawCircle(size / 2f, size / 2f, size / 2f, p);
        return out;
    }

    static void fetchAsync(final String url, final Callback cb) {
        pool.execute(() -> {
            Bitmap b = fetch(url, 256);
            if (b != null) { cache.put(url, b); cb.done(b); }
        });
    }

    private static Bitmap fetch(String url, int maxW) {
        try {
            okhttp3.Response r = HttpDownloader.client()
                .newCall(new okhttp3.Request.Builder().url(url).build()).execute();
            byte[] data = r.body().bytes();
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, o);
            int sample = 1;
            while (o.outWidth / (sample * 2) >= maxW) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            return BitmapFactory.decodeByteArray(data, 0, data.length, o2);
        } catch (Throwable e) {
            return null;
        }
    }
}
