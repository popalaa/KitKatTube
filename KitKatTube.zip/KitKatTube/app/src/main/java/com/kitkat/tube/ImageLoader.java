package com.kitkat.tube;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class ImageLoader {
    interface Callback { void done(Bitmap b); }

    private static final LruCache<String, Bitmap> cache =
        new LruCache<String, Bitmap>(8 * 1024 * 1024) {
            @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
        };
    private static final ExecutorService pool = Executors.newFixedThreadPool(3);
    private static final Handler ui = new Handler(Looper.getMainLooper());

    private ImageLoader() {}

    static Bitmap cached(String url) { return cache.get(url); }

    static void load(final String url, final ImageView iv) {
        iv.setTag(url);
        iv.setImageBitmap(null);
        if (url == null) return;
        Bitmap c = cache.get(url);
        if (c != null) { iv.setImageBitmap(c); return; }
        pool.execute(() -> {
            final Bitmap b = fetch(url, 320);
            if (b == null) return;
            cache.put(url, b);
            ui.post(() -> { if (url.equals(iv.getTag())) iv.setImageBitmap(b); });
        });
    }

    static void fetchAsync(final String url, final Callback cb) {
        pool.execute(() -> {
            Bitmap b = fetch(url, 256);
            if (b != null) { cache.put(url, b); cb.done(b); }
        });
    }

    private static Bitmap fetch(String url, int maxW) {
        try {
            okhttp3.Response r = HttpDownloader.client()
                .newCall(new okhttp3.Request.Builder().url(url).build()).execute();
            byte[] data = r.body().bytes();
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, o);
            int sample = 1;
            while (o.outWidth / (sample * 2) >= maxW) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            return BitmapFactory.decodeByteArray(data, 0, data.length, o2);
        } catch (Throwable e) {
            return null;
        }
    }
}
