package com.kitkat.tube;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.schabi.newpipe.extractor.InfoItem;
import org.schabi.newpipe.extractor.ListExtractor;
import org.schabi.newpipe.extractor.ListExtractor.InfoItemsPage;
import org.schabi.newpipe.extractor.Page;
import org.schabi.newpipe.extractor.ServiceList;
import org.schabi.newpipe.extractor.search.SearchExtractor;
import org.schabi.newpipe.extractor.stream.StreamInfoItem;

public class MainActivity extends AppCompatActivity {
    interface Source { ListExtractor<? extends InfoItem> create() throws Exception; }

    private static final String[] CHIP_NAMES =
        {"الكل", "موسيقى", "ألعاب", "أخبار", "رياضة", "أفلام", "طبخ", "تعليم", "بودكاست"};
    private static final int HOME = 0, SUBS = 1, HIST = 2;

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ExecutorService sugIo = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<TextView> chipViews = new ArrayList<>();
    private CardAdapter adapter;
    private GridView grid;
    private EditText query;
    private ProgressBar progress;
    private TextView empty, clearHistory, tabHome, tabSubs, tabHistory;
    private View chipsScroll, subsStrip;
    private LinearLayout subsRow;
    private ListView suggest;
    private ArrayAdapter<String> suggestAdapter;
    private Runnable suggestTask;
    private boolean suppressSuggest;
    private ListExtractor<? extends InfoItem> extractor;
    private Page nextPage;
    private boolean hasMore, loading;
    private int mode = HOME, gen;
    private String lastSubsSig = "";

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_main);
        query = findViewById(R.id.query);
        progress = findViewById(R.id.progress);
        grid = findViewById(R.id.grid);
        empty = findViewById(R.id.empty);
        clearHistory = findViewById(R.id.clearHistory);
        tabHome = findViewById(R.id.tabHome);
        tabSubs = findViewById(R.id.tabSubs);
        tabHistory = findViewById(R.id.tabHistory);
        chipsScroll = findViewById(R.id.chipsScroll);
        subsStrip = findViewById(R.id.subsStrip);
        subsRow = findViewById(R.id.subsRow);
        suggest = findViewById(R.id.suggest);

        adapter = new CardAdapter(this, r -> openChannel(r.channelUrl, r.uploader));
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((p, v, pos, id) -> {
            Intent i = new Intent(this, PlayerActivity.class);
            i.putExtra("url", adapter.items.get(pos).url);
            startActivity(i);
        });
        grid.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(AbsListView v, int st) { }
            @Override public void onScroll(AbsListView v, int first, int visible, int total) {
                if (total > 0 && first + visible >= total - 3 && hasMore && !loading) loadMore();
            }
        });
        grid.setOnTouchListener((v, e) -> { suggest.setVisibility(View.GONE); return false; });

        LinearLayout chips = findViewById(R.id.chips);
        for (int i = 0; i < CHIP_NAMES.length; i++) {
            final int idx = i;
            TextView c = new TextView(this);
            c.setText(CHIP_NAMES[i]);
            c.setTextSize(13);
            c.setPadding(dp(14), dp(8), dp(14), dp(8));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(8);
            c.setLayoutParams(lp);
            c.setOnClickListener(v -> selectChip(idx));
            chips.addView(c);
            chipViews.add(c);
        }

        // اقتراحات البحث
        suggestAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>());
        suggest.setAdapter(suggestAdapter);
        suggest.setOnItemClickListener((p, v, pos, id) -> {
            String q = suggestAdapter.getItem(pos);
            suppressSuggest = true;
            query.setText(q);
            query.setSelection(q.length());
            suppressSuggest = false;
            doSearch();
        });
        query.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) {
                if (suggestTask != null) handler.removeCallbacks(suggestTask);
                final String q = e.toString().trim();
                if (suppressSuggest || q.isEmpty()) { suggest.setVisibility(View.GONE); return; }
                suggestTask = () -> fetchSuggestions(q);
                handler.postDelayed(suggestTask, 250);
            }
        });

        findViewById(R.id.searchBtn).setOnClickListener(v -> doSearch());
        query.setOnEditorActionListener((v, a, e) -> {
            if (a == EditorInfo.IME_ACTION_SEARCH) { doSearch(); return true; }
            return false;
        });
        tabHome.setOnClickListener(v -> { if (mode != HOME) selectChip(0); });
        tabSubs.setOnClickListener(v -> showSubs());
        tabHistory.setOnClickListener(v -> showHistory());
        clearHistory.setOnClickListener(v -> { History.clear(this); showHistory(); });

        showCrashIfAny();
        selectChip(0);
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private void openChannel(String url, String name) {
        if (url == null) return;
        Intent i = new Intent(this, ChannelActivity.class);
        i.putExtra("url", url);
        i.putExtra("name", name);
        startActivity(i);
    }

    // ---------------- اقتراحات البحث ----------------

    private void fetchSuggestions(final String q) {
        sugIo.execute(() -> {
            try {
                final List<String> list =
                    ServiceList.YouTube.getSuggestionExtractor().suggestionList(q);
                runOnUiThread(() -> {
                    if (!q.equals(query.getText().toString().trim())) return;
                    suggestAdapter.clear();
                    int n = 0;
                    for (String x : list) { if (n++ < 8) suggestAdapter.add(x); }
                    suggestAdapter.notifyDataSetChanged();
                    suggest.setVisibility(suggestAdapter.getCount() > 0 ? View.VISIBLE : View.GONE);
                });
            } catch (Throwable ignored) { }
        });
    }

    // ---------------- الأقسام ----------------

    private void styleTabs() {
        tabHome.setTextColor(mode == HOME ? 0xFFFF4444 : 0xFFAAAAAA);
        tabSubs.setTextColor(mode == SUBS ? 0xFFFF4444 : 0xFFAAAAAA);
        tabHistory.setTextColor(mode == HIST ? 0xFFFF4444 : 0xFFAAAAAA);
        chipsScroll.setVisibility(mode == HOME ? View.VISIBLE : View.GONE);
        clearHistory.setVisibility(mode == HIST ? View.VISIBLE : View.GONE);
        if (mode != SUBS) subsStrip.setVisibility(View.GONE);
    }

    private void styleChips(int selected) {
        for (int i = 0; i < chipViews.size(); i++) {
            TextView c = chipViews.get(i);
            boolean sel = i == selected;
            c.setBackgroundResource(sel ? R.drawable.bg_chip_sel : R.drawable.bg_chip);
            c.setTextColor(sel ? 0xFF000000 : 0xFFFFFFFF);
        }
    }

    private void selectChip(int i) {
        mode = HOME;
        styleTabs();
        styleChips(i);
        suggest.setVisibility(View.GONE);
        if (i < 0) return;
        if (i == 0) loadFeed(MainActivity::homeSource);
        else {
            final String term = CHIP_NAMES[i];
            loadFeed(() -> search(term));
        }
    }

    private void showHistory() {
        gen++;
        mode = HIST;
        hasMore = false;
        loading = false;
        styleTabs();
        suggest.setVisibility(View.GONE);
        progress.setVisibility(View.GONE);
        adapter.items.clear();
        adapter.items.addAll(History.load(this));
        adapter.notifyDataSetChanged();
        grid.setSelection(0);
        empty.setText("السجل فاضي");
        empty.setVisibility(adapter.items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void showSubs() {
        final int g = ++gen;
        mode = SUBS;
        hasMore = false;
        loading = true;
        styleTabs();
        suggest.setVisibility(View.GONE);
        lastSubsSig = Subs.signature(this);
        adapter.items.clear();
        adapter.notifyDataSetChanged();
        final List<Subs.Chan> subs = Subs.load(this);
        fillStrip(subs);
        if (subs.isEmpty()) {
            loading = false;
            progress.setVisibility(View.GONE);
            empty.setText("لسه ما اشتركتش في أي قناة\nافتح أي قناة واضغط \"اشترك\"");
            empty.setVisibility(View.VISIBLE);
            return;
        }
        progress.setVisibility(View.VISIBLE);
        empty.setVisibility(View.GONE);
        io.execute(() -> {
            List<Row> all = new ArrayList<>();
            for (int i = 0; i < subs.size() && i < 25; i++) {
                if (g != gen) return;
                Subs.Chan c = subs.get(i);
                if (c.id == null) continue;
                try {
                    List<Row> r = Rss.fetch(c.id);
                    all.addAll(r.subList(0, Math.min(r.size(), 8)));
                } catch (Throwable ignored) { }
            }
            Collections.sort(all, (a, b) -> Long.compare(b.ts, a.ts));
            final List<Row> res = all.size() > 80 ? new ArrayList<>(all.subList(0, 80)) : all;
            runOnUiThread(() -> {
                if (g != gen) return;
                adapter.items.clear();
                adapter.items.addAll(res);
                adapter.notifyDataSetChanged();
                grid.setSelection(0);
                loading = false;
                progress.setVisibility(View.GONE);
                empty.setText("مفيش فيديوهات جديدة");
                empty.setVisibility(res.isEmpty() ? View.VISIBLE : View.GONE);
            });
        });
    }

    private void fillStrip(List<Subs.Chan> subs) {
        subsRow.removeAllViews();
        subsStrip.setVisibility(subs.isEmpty() ? View.GONE : View.VISIBLE);
        LayoutInflater inf = LayoutInflater.from(this);
        for (final Subs.Chan c : subs) {
            View v = inf.inflate(R.layout.item_sub, subsRow, false);
            Avatar.apply((TextView) v.findViewById(R.id.subLetter), c.name);
            ((TextView) v.findViewById(R.id.subName)).setText(c.name);
            ImageView img = (ImageView) v.findViewById(R.id.subImg);
            if (c.avatar != null) ImageLoader.loadCircle(c.avatar, img);
            v.setOnClickListener(x -> openChannel(c.url, c.name));
            subsRow.addView(v);
        }
    }

    private void doSearch() {
        final String q = query.getText().toString().trim();
        if (q.isEmpty()) return;
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(query.getWindowToken(), 0);
        suggest.setVisibility(View.GONE);
        mode = HOME;
        styleTabs();
        styleChips(-1);
        loadFeed(() -> search(q));
    }

    private static ListExtractor<? extends InfoItem> search(String q) throws Exception {
        SearchExtractor ex = ServiceList.YouTube.getSearchExtractor(q);
        ex.fetchPage();
        return ex;
    }

    /** الصفحة الرئيسية: الرائج لو متاح، وإلا بحث عام. */
    private static ListExtractor<? extends InfoItem> homeSource() throws Exception {
        try {
            ListExtractor<? extends InfoItem> k =
                ServiceList.YouTube.getKioskList().getDefaultKioskExtractor();
            k.fetchPage();
            if (!k.getInitialPage().getItems().isEmpty()) return k;
        } catch (Throwable ignored) { }
        return search("الأكثر مشاهدة");
    }

    private void loadFeed(final Source src) {
        final int g = ++gen;
        loading = true;
        hasMore = false;
        progress.setVisibility(View.VISIBLE);
        empty.setVisibility(View.GONE);
        io.execute(() -> {
            try {
                ListExtractor<? extends InfoItem> ex = src.create();
                InfoItemsPage<? extends InfoItem> p = ex.getInitialPage();
                final List<Row> rows = rows(p);
                final Page np = p.getNextPage();
                final boolean more = p.hasNextPage();
                runOnUiThread(() -> {
                    if (g != gen) return;
                    extractor = ex;
                    nextPage = np;
                    adapter.items.clear();
                    adapter.items.addAll(rows);
                    adapter.notifyDataSetChanged();
                    grid.setSelection(0);
                    hasMore = more;
                    loading = false;
                    progress.setVisibility(View.GONE);
                    empty.setText("مفيش نتائج");
                    empty.setVisibility(rows.isEmpty() ? View.VISIBLE : View.GONE);
                });
            } catch (Throwable e) {
                // طلب اتلغى أثناء قفل الأكتيفيتي: اخرج بهدوء من غير ديالوج خطأ
                if (io.isShutdown() || isCancel(e)) {
                    runOnUiThread(() -> { if (g == gen) { loading = false; progress.setVisibility(View.GONE); } });
                    return;
                }
                final String tr = trace(e);
                runOnUiThread(() -> {
                    if (g != gen) return;
                    loading = false;
                    progress.setVisibility(View.GONE);
                    showError(tr);
                });
            }
        });
    }

    private void loadMore() {
        if (extractor == null || nextPage == null || mode != HOME) return;
        final int g = gen;
        loading = true;
        final ListExtractor<? extends InfoItem> ex = extractor;
        final Page np = nextPage;
        io.execute(() -> {
            try {
                InfoItemsPage<? extends InfoItem> p = ex.getPage(np);
                final List<Row> rows = rows(p);
                final Page nn = p.getNextPage();
                final boolean more = p.hasNextPage();
                runOnUiThread(() -> {
                    if (g != gen) return;
                    nextPage = nn;
                    adapter.items.addAll(rows);
                    adapter.notifyDataSetChanged();
                    hasMore = more;
                    loading = false;
                });
            } catch (Throwable e) {
                runOnUiThread(() -> { hasMore = false; loading = false; });
            }
        });
    }

    private static List<Row> rows(InfoItemsPage<? extends InfoItem> p) {
        List<Row> out = new ArrayList<>();
        for (InfoItem it : p.getItems()) {
            if (it instanceof StreamInfoItem) out.add(Row.from((StreamInfoItem) it));
        }
        return out;
    }

    private void showCrashIfAny() {
        java.io.File cf = new java.io.File(getFilesDir(), "crash.txt");
        if (!cf.exists()) return;
        try {
            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader(cf));
            StringBuilder sb = new StringBuilder();
            String l;
            while ((l = br.readLine()) != null && sb.length() < 3500) sb.append(l).append('\n');
            br.close();
            cf.delete();
            showError("Last crash:\n" + sb);
        } catch (Exception ignored) { }
    }

    /** بيميّز الطلب الملغي (interrupt أثناء قفل الأكتيفيتي) عن الأخطاء الحقيقية زي انتهاء المهلة. */
    static boolean isCancel(Throwable e) {
        while (e != null) {
            if (e instanceof java.io.InterruptedIOException && "interrupted".equals(e.getMessage()))
                return true;
            e = e.getCause();
        }
        return false;
    }

    static String trace(Throwable e) {
        java.io.StringWriter sw = new java.io.StringWriter();
        e.printStackTrace(new java.io.PrintWriter(sw));
        String t = sw.toString();
        return t.length() > 3500 ? t.substring(0, 3500) : t;
    }

    void showError(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(11);
        tv.setTextIsSelectable(true);
        tv.setPadding(24, 24, 24, 24);
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.addView(tv);
        new androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Error").setView(sv).setPositiveButton("OK", null).show();
    }

    @Override protected void onResume() {
        super.onResume();
        if (mode == HIST) showHistory();
        else if (mode == SUBS && !Subs.signature(this).equals(lastSubsSig)) showSubs();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
        sugIo.shutdownNow();
    }
}
