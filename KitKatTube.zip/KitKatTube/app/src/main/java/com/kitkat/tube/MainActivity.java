package com.kitkat.tube;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.schabi.newpipe.extractor.InfoItem;
import org.schabi.newpipe.extractor.ListExtractor.InfoItemsPage;
import org.schabi.newpipe.extractor.Page;
import org.schabi.newpipe.extractor.ServiceList;
import org.schabi.newpipe.extractor.search.SearchExtractor;
import org.schabi.newpipe.extractor.stream.StreamInfoItem;

public class MainActivity extends AppCompatActivity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private VideoAdapter adapter;
    private EditText query;
    private ProgressBar progress;
    private SearchExtractor extractor;
    private Page nextPage;
    private boolean hasMore, loading;

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_main);
        query = findViewById(R.id.query);
        progress = findViewById(R.id.progress);
        ListView list = findViewById(R.id.list);
        adapter = new VideoAdapter(this);
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> {
            StreamInfoItem it = adapter.items.get(pos);
            Intent i = new Intent(this, PlayerActivity.class);
            i.putExtra("url", it.getUrl());
            startActivity(i);
        });
        list.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(AbsListView v, int st) { }
            @Override public void onScroll(AbsListView v, int first, int visible, int total) {
                if (total > 0 && first + visible >= total - 2 && hasMore && !loading) loadMore();
            }
        });

        showCrashIfAny();

        findViewById(R.id.searchBtn).setOnClickListener(v -> search());
        query.setOnEditorActionListener((v, a, e) -> {
            if (a == EditorInfo.IME_ACTION_SEARCH) { search(); return true; }
            return false;
        });
    }

    private void showCrashIfAny() {
        java.io.File cf = new java.io.File(getFilesDir(), "crash.txt");
        if (!cf.exists()) return;
        try {
            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader(cf));
            StringBuilder sb = new StringBuilder();
            String l;
            while ((l = br.readLine()) != null && sb.length() < 3500) sb.append(l).append('\n');
            br.close();
            cf.delete();
            showError("Last crash:\n" + sb);
        } catch (Exception ignored) { }
    }

    static String trace(Throwable e) {
        java.io.StringWriter sw = new java.io.StringWriter();
        e.printStackTrace(new java.io.PrintWriter(sw));
        String t = sw.toString();
        return t.length() > 3500 ? t.substring(0, 3500) : t;
    }

    void showError(String text) {
        android.widget.TextView tv = new android.widget.TextView(this);
        tv.setText(text);
        tv.setTextSize(11);
        tv.setTextIsSelectable(true);
        tv.setPadding(24, 24, 24, 24);
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.addView(tv);
        new androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Error").setView(sv).setPositiveButton("OK", null).show();
    }

    private void search() {
        final String q = query.getText().toString().trim();
        if (q.isEmpty()) return;
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(query.getWindowToken(), 0);
        loading = true;
        hasMore = false;
        progress.setVisibility(View.VISIBLE);
        io.execute(() -> {
            try {
                SearchExtractor ex = ServiceList.YouTube.getSearchExtractor(q);
                ex.fetchPage();
                InfoItemsPage<InfoItem> p = ex.getInitialPage();
                final List<StreamInfoItem> found = streams(p);
                extractor = ex;
                nextPage = p.getNextPage();
                final boolean more = p.hasNextPage();
                runOnUiThread(() -> {
                    adapter.items.clear();
                    adapter.items.addAll(found);
                    adapter.notifyDataSetChanged();
                    hasMore = more;
                    loading = false;
                    progress.setVisibility(View.GONE);
                });
            } catch (Throwable e) {
                final String tr = trace(e);
                runOnUiThread(() -> {
                    loading = false;
                    progress.setVisibility(View.GONE);
                    showError(tr);
                });
            }
        });
    }

    private void loadMore() {
        if (extractor == null || nextPage == null) return;
        loading = true;
        progress.setVisibility(View.VISIBLE);
        final SearchExtractor ex = extractor;
        final Page np = nextPage;
        io.execute(() -> {
            try {
                InfoItemsPage<InfoItem> p = ex.getPage(np);
                final List<StreamInfoItem> found = streams(p);
                nextPage = p.getNextPage();
                final boolean more = p.hasNextPage();
                runOnUiThread(() -> {
                    adapter.items.addAll(found);
                    adapter.notifyDataSetChanged();
                    hasMore = more;
                    loading = false;
                    progress.setVisibility(View.GONE);
                });
            } catch (Throwable e) {
                runOnUiThread(() -> {
                    hasMore = false;
                    loading = false;
                    progress.setVisibility(View.GONE);
                });
            }
        });
    }

    private static List<StreamInfoItem> streams(InfoItemsPage<InfoItem> p) {
        List<StreamInfoItem> out = new ArrayList<>();
        for (InfoItem it : p.getItems()) if (it instanceof StreamInfoItem) out.add((StreamInfoItem) it);
        return out;
    }

    @Override protected void onDestroy() { super.onDestroy(); io.shutdownNow(); }
}
