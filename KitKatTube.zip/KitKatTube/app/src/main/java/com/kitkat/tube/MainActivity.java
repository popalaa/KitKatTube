package com.kitkat.tube;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.schabi.newpipe.extractor.InfoItem;
import org.schabi.newpipe.extractor.ServiceList;
import org.schabi.newpipe.extractor.search.SearchExtractor;
import org.schabi.newpipe.extractor.stream.StreamInfoItem;

public class MainActivity extends AppCompatActivity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final List<StreamInfoItem> results = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private EditText query;
    private ProgressBar progress;

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_main);
        query = findViewById(R.id.query);
        progress = findViewById(R.id.progress);
        ListView list = findViewById(R.id.list);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_2, android.R.id.text1, new ArrayList<String>()) {
            @Override public View getView(int pos, View v, android.view.ViewGroup parent) {
                v = super.getView(pos, v, parent);
                ((android.widget.TextView) v.findViewById(android.R.id.text2))
                    .setText(results.get(pos).getUploaderName());
                return v;
            }
        };
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> {
            Intent i = new Intent(this, PlayerActivity.class);
            i.putExtra("url", results.get(pos).getUrl());
            startActivity(i);
        });
        findViewById(R.id.searchBtn).setOnClickListener(v -> search());
        query.setOnEditorActionListener((v, a, e) -> {
            if (a == EditorInfo.IME_ACTION_SEARCH) { search(); return true; }
            return false;
        });
    }

    private void search() {
        final String q = query.getText().toString().trim();
        if (q.isEmpty()) return;
        progress.setVisibility(View.VISIBLE);
        io.execute(() -> {
            try {
                SearchExtractor ex = ServiceList.YouTube.getSearchExtractor(q);
                ex.fetchPage();
                final List<StreamInfoItem> found = new ArrayList<>();
                for (InfoItem it : ex.getInitialPage().getItems())
                    if (it instanceof StreamInfoItem) found.add((StreamInfoItem) it);
                runOnUiThread(() -> {
                    results.clear(); results.addAll(found);
                    adapter.clear();
                    for (StreamInfoItem i : found) adapter.add(i.getName());
                    progress.setVisibility(View.GONE);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    Toast.makeText(this, "خطأ: " + e, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    @Override protected void onDestroy() { super.onDestroy(); io.shutdownNow(); }
}
