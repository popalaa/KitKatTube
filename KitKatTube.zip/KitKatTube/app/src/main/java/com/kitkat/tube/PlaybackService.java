package com.kitkat.tube;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.widget.Toast;
import com.google.android.exoplayer2.C;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.PlaybackException;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.audio.AudioAttributes;
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.MergingMediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.ui.PlayerNotificationManager;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource;
import java.util.ArrayList;
import java.util.List;

/** يملك المشغّل: التشغيل يكمل في الخلفية + إشعار تحكم + SponsorBlock. */
public class PlaybackService extends Service {
    public static class Seg { long start, end; String category; }

    public class LocalBinder extends Binder {
        PlaybackService get() { return PlaybackService.this; }
    }

    private static final String CHANNEL = "kitkattube_playback";
    private static final int NOTIF_ID = 42;

    private final IBinder binder = new LocalBinder();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private ExoPlayer player;
    private PlayerNotificationManager nm;
    private DefaultHttpDataSource.Factory dsf;

    String currentUrl, quality, title, uploader, thumb;
    private String fallback;
    private boolean merged, usingFallback;
    volatile boolean sbEnabled = true;
    private volatile List<Seg> segs = new ArrayList<>();

    @Override public void onCreate() {
        super.onCreate();
        dsf = new DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(20000).setReadTimeoutMs(20000)
            .setAllowCrossProtocolRedirects(true);
        AudioAttributes aa = new AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build();
        player = new ExoPlayer.Builder(this)
            .setAudioAttributes(aa, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build();
        player.addListener(new Player.Listener() {
            @Override public void onPlayerError(PlaybackException e) { handleError(e); }
        });

        nm = new PlayerNotificationManager.Builder(this, NOTIF_ID, CHANNEL)
            .setChannelNameResourceId(R.string.channel_name)
            .setMediaDescriptionAdapter(new PlayerNotificationManager.MediaDescriptionAdapter() {
                @Override public CharSequence getCurrentContentTitle(Player p) {
                    return title == null ? "" : title;
                }
                @Override public PendingIntent createCurrentContentIntent(Player p) {
                    Intent i = new Intent(PlaybackService.this, PlayerActivity.class);
                    i.putExtra("url", currentUrl);
                    i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    int flags = PendingIntent.FLAG_UPDATE_CURRENT;
                    if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
                    return PendingIntent.getActivity(PlaybackService.this, 0, i, flags);
                }
                @Override public CharSequence getCurrentContentText(Player p) { return uploader; }
                @Override public Bitmap getCurrentLargeIcon(Player p,
                        final PlayerNotificationManager.BitmapCallback cb) {
                    String t = thumb;
                    if (t == null) return null;
                    Bitmap c = ImageLoader.cached(t);
                    if (c != null) return c;
                    ImageLoader.fetchAsync(t, b -> cb.onBitmap(b));
                    return null;
                }
            })
            .setNotificationListener(new PlayerNotificationManager.NotificationListener() {
                @Override public void onNotificationPosted(int id, Notification n, boolean ongoing) {
                    if (ongoing) startForeground(id, n); else stopForeground(false);
                }
                @Override public void onNotificationCancelled(int id, boolean byUser) {
                    stopForeground(true);
                    stopSelf();
                }
            })
            .build();
        nm.setUseNextAction(false);
        nm.setUsePreviousAction(false);
        nm.setUseStopAction(true);
        nm.setSmallIcon(android.R.drawable.ic_media_play);
        nm.setPlayer(player);

        handler.post(sbTick);
    }

    private final Runnable sbTick = new Runnable() {
        @Override public void run() {
            try {
                if (sbEnabled && player != null && player.isPlaying()) {
                    long pos = player.getCurrentPosition();
                    for (Seg s : segs) {
                        if (pos >= s.start && pos < s.end - 250) {
                            player.seekTo(s.end);
                            Toast.makeText(PlaybackService.this,
                                "تم تخطي: " + s.category, Toast.LENGTH_SHORT).show();
                            break;
                        }
                    }
                }
            } catch (Throwable ignored) { }
            handler.postDelayed(this, 300);
        }
    };

    ExoPlayer getPlayer() { return player; }

    void setSegments(List<Seg> list) { segs = list; }

    void setVideoEnabled(boolean enabled) {
        player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, !enabled).build());
    }

    private MediaSource build(String video, String audio, String muxed) {
        if (video != null && audio != null) {
            ProgressiveMediaSource.Factory pf = new ProgressiveMediaSource.Factory(dsf);
            MediaSource v = pf.createMediaSource(MediaItem.fromUri(video));
            MediaSource a = pf.createMediaSource(MediaItem.fromUri(audio));
            return new MergingMediaSource(v, a);
        }
        return new DefaultMediaSourceFactory(dsf).createMediaSource(MediaItem.fromUri(muxed));
    }

    void play(String pageUrl, String title, String uploader, String thumb,
              String video, String audio, String muxed, String fallback,
              long startMs, String quality) {
        this.currentUrl = pageUrl;
        this.title = title;
        this.uploader = uploader;
        this.thumb = thumb;
        this.fallback = fallback;
        this.quality = quality;
        this.merged = video != null && audio != null;
        this.usingFallback = false;
        player.setMediaSource(build(video, audio, muxed), startMs);
        player.prepare();
        player.play();
        if (nm != null) nm.invalidate();
    }

    private void handleError(PlaybackException e) {
        String cause = e.getCause() != null ? String.valueOf(e.getCause().getMessage()) : "";
        if (merged && !usingFallback && fallback != null) {
            usingFallback = true;
            long pos = player.getCurrentPosition();
            player.setMediaSource(build(null, null, fallback), pos);
            player.prepare();
            player.play();
            Toast.makeText(this, "فشلت الجودة العالية (" + e.getErrorCodeName()
                + ")، تم التحويل للجودة المضمونة", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "خطأ تشغيل: " + e.getErrorCodeName() + " " + cause,
                Toast.LENGTH_LONG).show();
        }
    }

    @Override public IBinder onBind(Intent intent) { return binder; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (nm != null) nm.setPlayer(null);
        if (player != null) player.release();
        super.onDestroy();
    }
}
