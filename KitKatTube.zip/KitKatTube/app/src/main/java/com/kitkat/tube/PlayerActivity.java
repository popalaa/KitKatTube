package com.kitkat.tube;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.ui.StyledPlayerView;
import java.util.List;
import org.schabi.newpipe.extractor.stream.StreamInfo;
import org.schabi.newpipe.extractor.stream.VideoStream;

public class PlayerActivity extends AppCompatActivity {
    private ExoPlayer player;
    private TextView status;

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_player);
        status = findViewById(R.id.status);
        final StyledPlayerView view = findViewById(R.id.player);
        player = new ExoPlayer.Builder(this).build();
        view.setPlayer(player);
        final String url = getIntent().getStringExtra("url");
        new Thread(() -> {
            try {
                StreamInfo info = StreamInfo.getInfo(url);
                String media = pickStream(info);
                runOnUiThread(() -> {
                    if (media == null) { status.setText("مفيش ستريم مناسب"); return; }
                    status.setVisibility(android.view.View.GONE);
                    player.setMediaItem(MediaItem.fromUri(media));
                    player.prepare();
                    player.play();
                });
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("خطأ: " + e));
            }
        }).start();
    }

    /** ستريمات muxed (صوت+صورة) فقط، أعلى جودة لحد 480p، وبعدين HLS. */
    private String pickStream(StreamInfo info) {
        List<VideoStream> muxed = info.getVideoStreams();
        VideoStream best = null;
        for (VideoStream v : muxed) {
            if (best == null || (v.getHeight() <= 480 && v.getHeight() > best.getHeight())) best = v;
        }
        if (best != null) return best.getContent();
        String hls = info.getHlsUrl();
        return (hls != null && !hls.isEmpty()) ? hls : null;
    }

    @Override protected void onStop() { super.onStop(); if (player != null) player.pause(); }
    @Override protected void onDestroy() { super.onDestroy(); if (player != null) player.release(); }
}
