package com.kitkat.tube;

import android.app.DownloadManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.text.Html;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.ui.StyledPlayerView;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.schabi.newpipe.extractor.Image;
import org.schabi.newpipe.extractor.InfoItem;
import org.schabi.newpipe.extractor.MediaFormat;
import org.schabi.newpipe.extractor.stream.AudioStream;
import org.schabi.newpipe.extractor.stream.DeliveryMethod;
import org.schabi.newpipe.extractor.stream.StreamInfo;
import org.schabi.newpipe.extractor.stream.StreamInfoItem;
import org.schabi.newpipe.extractor.stream.VideoStream;

public class PlayerActivity extends AppCompatActivity {
    static class Option { String label, video, audio, muxed; }

    private static final float[] SPEEDS = {0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f};

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private PlaybackService svc;
    private boolean bound, visible, started, loaded, userFull;
    private int gen;

    private View root, playerBox, header;
    private StyledPlayerView view;
    private TextView seekHint, loadingTv, hTitle, hMeta, hDesc, hAvatar, hChannel, hSubs;
    private TextView chipQ, chipSpeed, chipSb, chipAuto, chipDlV, chipDlA, chipComments, hSub;
    private ListView related;
    private VideoAdapter relatedAdapter;
    private SharedPreferences prefs;

    private String pageUrl, videoId, title, uploader, thumb, uploaderUrl;
    private final List<Option> options = new ArrayList<>();
    private int selected = -1;
    private String fallbackMuxed, downloadVideoUrl, downloadAudioUrl;
    private boolean autoplay = true, descOpen;
    private float speed = 1f;
    private int lastW = -1;
    private boolean lastFull;
    private final Runnable hideHint = () -> seekHint.setVisibility(View.GONE);

    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) {
            svc = ((PlaybackService.LocalBinder) b).get();
            svc.sbEnabled = prefs.getBoolean("sb", true);
            updateChips();
            if (visible) attach();
            tryStart();
        }
        @Override public void onServiceDisconnected(ComponentName n) { svc = null; }
    };

    private final Player.Listener playerListener = new Player.Listener() {
        @Override public void onPlaybackStateChanged(int state) {
            updateKeepOn();
            if (state == Player.STATE_READY) loadingTv.setVisibility(View.GONE);
            if (state == Player.STATE_ENDED && autoplay && visible && !relatedAdapter.items.isEmpty()) {
                openVideo(relatedAdapter.items.get(0).url);
            }
        }
        @Override public void onPlayWhenReadyChanged(boolean playWhenReady, int reason) { updateKeepOn(); }
    };

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_player);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        autoplay = prefs.getBoolean("auto", true);

        root = findViewById(R.id.root);
        playerBox = findViewById(R.id.playerBox);
        view = findViewById(R.id.player);
        seekHint = findViewById(R.id.seekHint);
        loadingTv = findViewById(R.id.loadingTv);
        related = findViewById(R.id.related);

        header = getLayoutInflater().inflate(R.layout.header_video, related, false);
        hTitle = header.findViewById(R.id.hTitle);
        hMeta = header.findViewById(R.id.hMeta);
        hDesc = header.findViewById(R.id.hDesc);
        hAvatar = header.findViewById(R.id.hAvatar);
        hChannel = header.findViewById(R.id.hChannel);
        hSubs = header.findViewById(R.id.hSubs);
        chipQ = header.findViewById(R.id.chipQ);
        chipSpeed = header.findViewById(R.id.chipSpeed);
        chipSb = header.findViewById(R.id.chipSb);
        chipAuto = header.findViewById(R.id.chipAuto);
        chipDlV = header.findViewById(R.id.chipDlV);
        chipDlA = header.findViewById(R.id.chipDlA);
        chipComments = header.findViewById(R.id.chipComments);
        hSub = header.findViewById(R.id.hSub);
        related.addHeaderView(header, null, false);
        relatedAdapter = new VideoAdapter(this);
        related.setAdapter(relatedAdapter);
        related.setOnItemClickListener((p, v, pos, id) -> {
            int idx = pos - related.getHeaderViewsCount();
            if (idx >= 0 && idx < relatedAdapter.items.size()) openVideo(relatedAdapter.items.get(idx).url);
        });

        // مشغّل بشكل يوتيوب
        view.setShowNextButton(false);
        view.setShowPreviousButton(false);
        view.setControllerOnFullScreenModeChangedListener(isFull -> setUserFull(isFull));
        final View gear = findViewById(R.id.gear);
        view.setControllerVisibilityListener(new StyledPlayerView.ControllerVisibilityListener() {
            @Override public void onVisibilityChanged(int visibility) { gear.setVisibility(visibility); }
        });
        gear.setOnClickListener(v -> showSettings());

        // دبل تاب: ±10 ثواني
        final GestureDetector gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDoubleTap(MotionEvent e) {
                if (svc == null) return false;
                boolean back = e.getX() < view.getWidth() / 2f;
                ExoPlayer p = svc.getPlayer();
                p.seekTo(Math.max(0, p.getCurrentPosition() + (back ? -10000 : 10000)));
                seekHint.setText(back ? "-10 ثواني" : "+10 ثواني");
                seekHint.setVisibility(View.VISIBLE);
                seekHint.removeCallbacks(hideHint);
                seekHint.postDelayed(hideHint, 600);
                return true;
            }
        });
        view.setOnTouchListener((v, ev) -> { gd.onTouchEvent(ev); return false; });

        header.findViewById(R.id.hChannelRow).setOnClickListener(v -> openChannel());
        hSub.setOnClickListener(v -> toggleSubscription());
        chipComments.setOnClickListener(v -> {
            Intent ci = new Intent(this, CommentsActivity.class);
            ci.putExtra("url", pageUrl);
            startActivity(ci);
        });
        chipQ.setOnClickListener(v -> showQualityDialog());
        chipSpeed.setOnClickListener(v -> showSpeedDialog());
        chipSb.setOnClickListener(v -> toggleSb());
        chipAuto.setOnClickListener(v -> toggleAuto());
        chipDlV.setOnClickListener(v -> download(downloadVideoUrl, ".mp4"));
        chipDlA.setOnClickListener(v -> download(downloadAudioUrl, ".m4a"));
        hDesc.setOnClickListener(v -> {
            descOpen = !descOpen;
            hDesc.setMaxLines(descOpen ? 60 : 2);
        });

        // يتحكم في الشكل حسب شكل الشاشة الفعلي (مش حسب إعدادات النظام)
        root.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            final int w = r - l, h = b - t;
            if (w <= 0 || h <= 0) return;
            boolean full = w > h || userFull;
            if (w != lastW || full != lastFull) {
                lastW = w;
                v.post(() -> applyLayout(w, h));
            }
        });

        pageUrl = getIntent().getStringExtra("url");
        updateChips();

        Intent si = new Intent(this, PlaybackService.class);
        startService(si);
        bound = bindService(si, conn, Context.BIND_AUTO_CREATE);
        openVideo(pageUrl);
    }

    // ---------------- الشكل: عمودي / ملء الشاشة ----------------

    private void applyLayout(int w, int h) {
        boolean full = w > h || userFull;
        lastFull = full;
        lastW = w;
        ViewGroup.LayoutParams lp = playerBox.getLayoutParams();
        lp.height = full ? ViewGroup.LayoutParams.MATCH_PARENT : w * 9 / 16;
        playerBox.setLayoutParams(lp);
        related.setVisibility(full ? View.GONE : View.VISIBLE);
        applySystemUi(full);
    }

    private void applySystemUi(boolean full) {
        int flags = View.SYSTEM_UI_FLAG_VISIBLE;
        if (full) {
            flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        }
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    private void setUserFull(boolean full) {
        userFull = full;
        setRequestedOrientation(full ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            : ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        if (lastW > 0) applyLayout(root.getWidth(), root.getHeight());
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && lastFull) applySystemUi(true);
    }

    @Override public void onBackPressed() {
        if (userFull) { setUserFull(false); return; }
        super.onBackPressed();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String u = intent.getStringExtra("url");
        if (u != null && !u.equals(pageUrl)) openVideo(u);
    }

    // ---------------- تحميل الفيديو ----------------

    private void openVideo(String url) {
        pageUrl = url;
        started = false;
        loaded = false;
        options.clear();
        selected = -1;
        fallbackMuxed = downloadVideoUrl = downloadAudioUrl = null;
        relatedAdapter.items.clear();
        relatedAdapter.notifyDataSetChanged();
        loadingTv.setText("جاري التحميل...");
        loadingTv.setVisibility(View.VISIBLE);
        hTitle.setText("");
        hMeta.setText("");
        hDesc.setVisibility(View.GONE);
        hChannel.setText("");
        hSubs.setText("");
        uploaderUrl = null;
        hSub.setVisibility(View.GONE);
        updateChips();
        final int g = ++gen;
        io.execute(() -> loadInfo(g));
    }

    private void loadInfo(final int g) {
        try {
            StreamInfo info = StreamInfo.getInfo(pageUrl);
            if (g != gen) return;
            final String t = info.getName();
            final String up = info.getUploaderName();
            final String id = info.getId();
            final String upUrl = info.getUploaderUrl();
            List<Image> th = info.getThumbnails();
            final String thumbUrl = th.isEmpty() ? null : th.get(th.size() - 1).getUrl();

            final long views = info.getViewCount();
            final String date = info.getTextualUploadDate() == null ? "" : info.getTextualUploadDate();
            String vs = Fmt.views(views);
            final String meta = vs.isEmpty() ? date : (date.isEmpty() ? vs : vs + " • " + date);
            final long subs = info.getUploaderSubscriberCount();
            String descRaw = "";
            try {
                if (info.getDescription() != null) descRaw = info.getDescription().getContent();
            } catch (Throwable ignored) { }
            final CharSequence desc = descRaw == null || descRaw.isEmpty()
                ? "" : Html.fromHtml(descRaw);

            AudioStream bestAudio = null;
            for (AudioStream a : info.getAudioStreams()) {
                if (a.getDeliveryMethod() != DeliveryMethod.PROGRESSIVE_HTTP) continue;
                if (a.getFormat() != MediaFormat.M4A) continue;
                if (bestAudio == null || a.getAverageBitrate() > bestAudio.getAverageBitrate()) bestAudio = a;
            }

            Map<Integer, VideoStream> byHeight = new TreeMap<>();
            for (VideoStream v : info.getVideoOnlyStreams()) {
                if (v.getDeliveryMethod() != DeliveryMethod.PROGRESSIVE_HTTP) continue;
                if (v.getFormat() != MediaFormat.MPEG_4) continue;
                String codec = v.getCodec();
                if (codec == null || !codec.startsWith("avc1")) continue;
                if (!byHeight.containsKey(v.getHeight())) byHeight.put(v.getHeight(), v);
            }

            VideoStream bestMuxed = null;
            for (VideoStream v : info.getVideoStreams()) {
                if (v.getDeliveryMethod() != DeliveryMethod.PROGRESSIVE_HTTP) continue;
                if (bestMuxed == null || v.getHeight() > bestMuxed.getHeight()) bestMuxed = v;
            }
            String hls = info.getHlsUrl();

            final List<Option> opts = new ArrayList<>();
            String fbMuxed = null, dlV = null, dlA = null;
            if (bestAudio != null) {
                List<Integer> hs = new ArrayList<>(byHeight.keySet());
                for (int i = hs.size() - 1; i >= 0; i--) {
                    int h = hs.get(i);
                    if (h > 1080) continue;
                    Option o = new Option();
                    o.label = h + "p";
                    o.video = byHeight.get(h).getContent();
                    o.audio = bestAudio.getContent();
                    opts.add(o);
                }
            }
            if (bestMuxed != null) {
                Option o = new Option();
                o.label = bestMuxed.getResolution() + " (صوت+صورة، مضمون)";
                o.muxed = bestMuxed.getContent();
                opts.add(o);
                fbMuxed = o.muxed;
                dlV = o.muxed;
            } else if (hls != null && !hls.isEmpty()) {
                Option o = new Option();
                o.label = "HLS (تلقائي)";
                o.muxed = hls;
                opts.add(o);
                fbMuxed = hls;
            }
            if (bestAudio != null) {
                Option o = new Option();
                o.label = "صوت فقط (توفير بيانات)";
                o.muxed = bestAudio.getContent();
                opts.add(o);
                dlA = bestAudio.getContent();
            }

            final List<Row> rel = new ArrayList<>();
            try {
                for (InfoItem it : info.getRelatedItems()) {
                    if (it instanceof StreamInfoItem) rel.add(Row.from((StreamInfoItem) it));
                }
            } catch (Throwable ignored) { }

            Row h = new Row();
            h.url = pageUrl;
            h.title = t;
            h.uploader = up;
            h.channelUrl = upUrl;
            h.thumb = thumbUrl;
            h.meta = meta;
            h.duration = info.getDuration();
            History.add(getApplicationContext(), h);

            final String fb = fbMuxed, fv = dlV, fa = dlA;
            runOnUiThread(() -> {
                if (g != gen) return;
                title = t;
                uploader = up;
                uploaderUrl = upUrl;
                videoId = id;
                thumb = thumbUrl;
                fallbackMuxed = fb;
                downloadVideoUrl = fv;
                downloadAudioUrl = fa;
                options.clear();
                options.addAll(opts);
                relatedAdapter.items.clear();
                relatedAdapter.items.addAll(rel);
                relatedAdapter.notifyDataSetChanged();
                hTitle.setText(t);
                hMeta.setText(meta);
                hChannel.setText(up);
                hSubs.setText(subs >= 0 ? Fmt.subs(subs) : "");
                Avatar.apply(hAvatar, up);
                if (desc.length() > 0) {
                    hDesc.setText(desc);
                    hDesc.setMaxLines(2);
                    descOpen = false;
                    hDesc.setVisibility(View.VISIBLE);
                }
                loaded = true;
                updateSubButton();
                if (options.isEmpty()) loadingTv.setText("مفيش ستريمات مناسبة للفيديو ده");
                updateChips();
                tryStart();
            });
        } catch (Throwable e) {
            final String tr = MainActivity.trace(e);
            runOnUiThread(() -> {
                if (g != gen) return;
                loadingTv.setText("حصل خطأ، اضغط لإعادة المحاولة");
                loadingTv.setOnClickListener(v -> {
                    loadingTv.setOnClickListener(null);
                    openVideo(pageUrl);
                });
                new AlertDialog.Builder(this).setTitle("Error")
                    .setMessage(tr).setPositiveButton("OK", null).show();
            });
        }
    }

    /** يشتغل لما الخدمة تتوصّل والمعلومات تجهز (أيهما الأخير). */
    private void tryStart() {
        if (started || svc == null || !loaded || options.isEmpty()) return;
        started = true;

        boolean already = pageUrl != null && pageUrl.equals(svc.currentUrl) && svc.quality != null;
        int idx = -1;
        if (already) {
            for (int i = 0; i < options.size(); i++) {
                if (options.get(i).label.equals(svc.quality)) { idx = i; break; }
            }
        }
        if (idx < 0) {
            for (int i = 0; i < options.size(); i++) {
                Option o = options.get(i);
                if (o.video != null && heightOf(o.label) <= 720) { idx = i; break; }
            }
            if (idx < 0) idx = 0;
            already = false;
        }
        selected = idx;
        updateChips();
        if (already) {
            loadingTv.setVisibility(View.GONE);
        } else {
            startOption(options.get(idx), 0);
            fetchSponsorBlock();
        }
    }

    private static int heightOf(String label) {
        try { return Integer.parseInt(label.substring(0, label.indexOf('p'))); }
        catch (Exception e) { return 9999; }
    }

    private void startOption(Option o, long startMs) {
        svc.play(pageUrl, title, uploader, thumb, o.video, o.audio, o.muxed,
            fallbackMuxed, startMs, o.label);
        svc.getPlayer().setPlaybackSpeed(speed);
    }

    private void fetchSponsorBlock() {
        final String id = videoId;
        final int g = gen;
        io.execute(() -> {
            try {
                final List<PlaybackService.Seg> segs = SponsorBlock.fetch(id);
                runOnUiThread(() -> { if (g == gen && svc != null) svc.setSegments(segs); });
            } catch (Throwable e) {
                runOnUiThread(() -> Toast.makeText(this,
                    "SponsorBlock غير متاح: " + e, Toast.LENGTH_LONG).show());
            }
        });
    }

    // ---------------- الأزرار والقوايم ----------------

    private void updateChips() {
        String q = selected >= 0 && selected < options.size() ? options.get(selected).label : "...";
        chipQ.setText("الجودة: " + q);
        chipSpeed.setText("السرعة: " + (speed == (int) speed ? String.valueOf((int) speed) : String.valueOf(speed)) + "x");
        boolean sb = svc == null ? prefs.getBoolean("sb", true) : svc.sbEnabled;
        chipSb.setText("تخطي الرعاة: " + (sb ? "تشغيل" : "إيقاف"));
        chipAuto.setText("تشغيل تلقائي: " + (autoplay ? "تشغيل" : "إيقاف"));
        chipDlV.setEnabled(downloadVideoUrl != null);
        chipDlA.setEnabled(downloadAudioUrl != null);
        chipDlV.setAlpha(downloadVideoUrl != null ? 1f : 0.4f);
        chipDlA.setAlpha(downloadAudioUrl != null ? 1f : 0.4f);
    }

    private void toggleSb() {
        boolean on = !(svc == null ? prefs.getBoolean("sb", true) : svc.sbEnabled);
        if (svc != null) svc.sbEnabled = on;
        prefs.edit().putBoolean("sb", on).apply();
        updateChips();
    }

    private void toggleAuto() {
        autoplay = !autoplay;
        prefs.edit().putBoolean("auto", autoplay).apply();
        updateChips();
    }

    private void showQualityDialog() {
        if (options.isEmpty() || svc == null) return;
        String[] labels = new String[options.size()];
        for (int i = 0; i < labels.length; i++) labels[i] = options.get(i).label;
        new AlertDialog.Builder(this).setTitle("الجودة")
            .setSingleChoiceItems(labels, selected, (d, which) -> {
                d.dismiss();
                if (which == selected) return;
                selected = which;
                long pos = svc.getPlayer().getCurrentPosition();
                startOption(options.get(which), pos);
                updateChips();
            }).show();
    }

    private void showSpeedDialog() {
        String[] labels = new String[SPEEDS.length];
        int cur = 2;
        for (int i = 0; i < SPEEDS.length; i++) {
            labels[i] = SPEEDS[i] + "x";
            if (SPEEDS[i] == speed) cur = i;
        }
        new AlertDialog.Builder(this).setTitle("سرعة التشغيل")
            .setSingleChoiceItems(labels, cur, (d, which) -> {
                d.dismiss();
                speed = SPEEDS[which];
                if (svc != null) svc.getPlayer().setPlaybackSpeed(speed);
                updateChips();
            }).show();
    }

    private void showSettings() {
        final String[] items = {
            chipQ.getText().toString(), chipSpeed.getText().toString(),
            chipSb.getText().toString(), chipAuto.getText().toString(),
            "تحميل الفيديو", "تحميل الصوت"};
        new AlertDialog.Builder(this).setItems(items, (d, which) -> {
            switch (which) {
                case 0: showQualityDialog(); break;
                case 1: showSpeedDialog(); break;
                case 2: toggleSb(); break;
                case 3: toggleAuto(); break;
                case 4: download(downloadVideoUrl, ".mp4"); break;
                default: download(downloadAudioUrl, ".m4a"); break;
            }
        }).show();
    }

    private void openChannel() {
        if (uploaderUrl == null) return;
        Intent i = new Intent(this, ChannelActivity.class);
        i.putExtra("url", uploaderUrl);
        i.putExtra("name", uploader);
        startActivity(i);
    }

    private void updateSubButton() {
        if (uploaderUrl == null) { hSub.setVisibility(View.GONE); return; }
        boolean sub = Subs.contains(this, uploaderUrl);
        hSub.setVisibility(View.VISIBLE);
        hSub.setText(sub ? "تم الاشتراك" : "اشترك");
        hSub.setBackgroundResource(sub ? R.drawable.bg_chip : R.drawable.bg_chip_sel);
        hSub.setTextColor(sub ? 0xFFFFFFFF : 0xFF000000);
    }

    private void toggleSubscription() {
        if (uploaderUrl == null) return;
        if (Subs.contains(this, uploaderUrl)) {
            Subs.remove(this, uploaderUrl);
        } else {
            String cid = Subs.idFromUrl(uploaderUrl);
            if (cid == null) {
                Toast.makeText(this, "افتح صفحة القناة واشترك من هناك", Toast.LENGTH_LONG).show();
                openChannel();
                return;
            }
            Subs.add(this, new Subs.Chan(cid, uploaderUrl, uploader == null ? "" : uploader, null));
        }
        updateSubButton();
    }

    private void download(String url, String ext) {
        if (url == null) return;
        try {
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            String name = Fmt.safeName(title == null ? "video" : title) + ext;
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            r.setTitle(name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            dm.enqueue(r);
            Toast.makeText(this, "بدأ التحميل في مجلد Downloads", Toast.LENGTH_LONG).show();
        } catch (Throwable e) {
            Toast.makeText(this, "فشل التحميل: " + e, Toast.LENGTH_LONG).show();
        }
    }

    // ---------------- الشاشة منورة أثناء التشغيل ----------------

    private void updateKeepOn() {
        boolean on = false;
        if (svc != null && visible) {
            ExoPlayer p = svc.getPlayer();
            int st = p.getPlaybackState();
            on = p.getPlayWhenReady() && st != Player.STATE_ENDED && st != Player.STATE_IDLE;
        }
        if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void attach() {
        if (svc == null) return;
        view.setPlayer(svc.getPlayer());
        svc.getPlayer().removeListener(playerListener);
        svc.getPlayer().addListener(playerListener);
        svc.setVideoEnabled(true);
        updateKeepOn();
    }

    @Override protected void onStart() {
        super.onStart();
        visible = true;
        attach();
        updateSubButton();
    }

    @Override protected void onStop() {
        visible = false;
        view.setPlayer(null);
        if (svc != null) {
            svc.getPlayer().removeListener(playerListener);
            svc.setVideoEnabled(false);
        }
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onStop();
    }

    @Override protected void onDestroy() {
        if (bound) unbindService(conn);
        io.shutdownNow();
        super.onDestroy();
    }
}
