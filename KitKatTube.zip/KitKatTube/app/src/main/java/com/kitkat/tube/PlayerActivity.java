package com.kitkat.tube;

import android.app.DownloadManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.exoplayer2.ui.StyledPlayerView;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.schabi.newpipe.extractor.Image;
import org.schabi.newpipe.extractor.MediaFormat;
import org.schabi.newpipe.extractor.stream.AudioStream;
import org.schabi.newpipe.extractor.stream.DeliveryMethod;
import org.schabi.newpipe.extractor.stream.StreamInfo;
import org.schabi.newpipe.extractor.stream.VideoStream;

public class PlayerActivity extends AppCompatActivity {
    static class Option {
        String label, video, audio, muxed;
    }

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private PlaybackService svc;
    private boolean bound, visible, started;
    private StyledPlayerView view;
    private TextView status, titleV, upV;
    private Spinner qualitySp;
    private CheckBox sbBox;
    private Button dlV, dlA;

    private String pageUrl, videoId, title, uploader, thumb;
    private final List<Option> options = new ArrayList<>();
    private int selected = -1;
    private String fallbackMuxed, downloadVideoUrl, downloadAudioUrl;
    private boolean loaded;

    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) {
            svc = ((PlaybackService.LocalBinder) b).get();
            sbBox.setChecked(svc.sbEnabled);
            if (visible) attach();
            tryStart();
        }
        @Override public void onServiceDisconnected(ComponentName n) { svc = null; }
    };

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_player);
        view = findViewById(R.id.player);
        status = findViewById(R.id.status);
        titleV = findViewById(R.id.titleV);
        upV = findViewById(R.id.upV);
        qualitySp = findViewById(R.id.quality);
        sbBox = findViewById(R.id.sb);
        dlV = findViewById(R.id.dlV);
        dlA = findViewById(R.id.dlA);
        dlV.setEnabled(false);
        dlA.setEnabled(false);

        pageUrl = getIntent().getStringExtra("url");

        sbBox.setOnCheckedChangeListener((b, checked) -> { if (svc != null) svc.sbEnabled = checked; });
        dlV.setOnClickListener(v -> download(downloadVideoUrl, ".mp4"));
        dlA.setOnClickListener(v -> download(downloadAudioUrl, ".m4a"));

        Intent si = new Intent(this, PlaybackService.class);
        startService(si);
        bound = bindService(si, conn, Context.BIND_AUTO_CREATE);

        io.execute(this::loadInfo);
    }

    private void loadInfo() {
        try {
            StreamInfo info = StreamInfo.getInfo(pageUrl);
            title = info.getName();
            uploader = info.getUploaderName();
            videoId = info.getId();
            List<Image> th = info.getThumbnails();
            thumb = th.isEmpty() ? null : th.get(th.size() - 1).getUrl();

            // أفضل صوت m4a
            AudioStream bestAudio = null;
            for (AudioStream a : info.getAudioStreams()) {
                if (a.getDeliveryMethod() != DeliveryMethod.PROGRESSIVE_HTTP) continue;
                if (a.getFormat() != MediaFormat.M4A) continue;
                if (bestAudio == null || a.getAverageBitrate() > bestAudio.getAverageBitrate()) bestAudio = a;
            }

            // فيديو منفصل H.264 (avc1) لأن الجهاز مش بيفك VP9 بالهاردوير
            Map<Integer, VideoStream> byHeight = new TreeMap<>();
            for (VideoStream v : info.getVideoOnlyStreams()) {
                if (v.getDeliveryMethod() != DeliveryMethod.PROGRESSIVE_HTTP) continue;
                if (v.getFormat() != MediaFormat.MPEG_4) continue;
                String codec = v.getCodec();
                if (codec == null || !codec.startsWith("avc1")) continue;
                if (!byHeight.containsKey(v.getHeight())) byHeight.put(v.getHeight(), v);
            }

            // ستريم جاهز (صوت+صورة)
            VideoStream bestMuxed = null;
            for (VideoStream v : info.getVideoStreams()) {
                if (v.getDeliveryMethod() != DeliveryMethod.PROGRESSIVE_HTTP) continue;
                if (bestMuxed == null || v.getHeight() > bestMuxed.getHeight()) bestMuxed = v;
            }
            String hls = info.getHlsUrl();

            final List<Option> opts = new ArrayList<>();
            if (bestAudio != null) {
                List<Integer> hs = new ArrayList<>(byHeight.keySet());
                for (int i = hs.size() - 1; i >= 0; i--) {
                    int h = hs.get(i);
                    if (h > 1080) continue;
                    Option o = new Option();
                    o.label = h + "p";
                    o.video = byHeight.get(h).getContent();
                    o.audio = bestAudio.getContent();
                    opts.add(o);
                }
            }
            if (bestMuxed != null) {
                Option o = new Option();
                o.label = bestMuxed.getResolution() + " (صوت+صورة، مضمون)";
                o.muxed = bestMuxed.getContent();
                opts.add(o);
                fallbackMuxed = o.muxed;
                downloadVideoUrl = o.muxed;
            } else if (hls != null && !hls.isEmpty()) {
                Option o = new Option();
                o.label = "HLS (تلقائي)";
                o.muxed = hls;
                opts.add(o);
                fallbackMuxed = hls;
            }
            if (bestAudio != null) {
                Option o = new Option();
                o.label = "صوت فقط (توفير بيانات)";
                o.muxed = bestAudio.getContent();
                opts.add(o);
                downloadAudioUrl = bestAudio.getContent();
            }

            runOnUiThread(() -> {
                options.clear();
                options.addAll(opts);
                loaded = true;
                titleV.setText(title);
                upV.setText(uploader);
                dlV.setEnabled(downloadVideoUrl != null);
                dlA.setEnabled(downloadAudioUrl != null);
                if (options.isEmpty()) {
                    status.setText("مفيش ستريمات مناسبة للفيديو ده");
                    return;
                }
                List<String> labels = new ArrayList<>();
                for (Option o : options) labels.add(o.label);
                ArrayAdapter<String> ad = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, labels);
                ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                qualitySp.setAdapter(ad);
                tryStart();
            });
        } catch (Throwable e) {
            final String tr = MainActivity.trace(e);
            runOnUiThread(() -> status.setText(tr));
        }
    }

    /** يشتغل لما الخدمة تتوصّل والمعلومات تجهز (أيهما الأخير). */
    private void tryStart() {
        if (started || svc == null || !loaded || options.isEmpty()) return;
        started = true;

        boolean already = pageUrl != null && pageUrl.equals(svc.currentUrl) && svc.quality != null;
        int idx = -1;
        if (already) {
            for (int i = 0; i < options.size(); i++) {
                if (options.get(i).label.equals(svc.quality)) { idx = i; break; }
            }
        }
        if (idx < 0) {
            // الافتراضي: أعلى جودة منفصلة حتى 720p
            for (int i = 0; i < options.size(); i++) {
                Option o = options.get(i);
                if (o.video != null && heightOf(o.label) <= 720) { idx = i; break; }
            }
            if (idx < 0) idx = 0;
            already = false;
        }
        selected = idx;
        qualitySp.setSelection(idx, false);
        qualitySp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (pos == selected || svc == null) return;
                selected = pos;
                long position = svc.getPlayer().getCurrentPosition();
                startOption(options.get(pos), position);
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });

        if (!already) {
            startOption(options.get(idx), 0);
            fetchSponsorBlock();
        } else {
            status.setText("");
        }
    }

    private static int heightOf(String label) {
        try { return Integer.parseInt(label.substring(0, label.indexOf('p'))); }
        catch (Exception e) { return 9999; }
    }

    private void startOption(Option o, long startMs) {
        svc.play(pageUrl, title, uploader, thumb, o.video, o.audio, o.muxed,
            fallbackMuxed, startMs, o.label);
        status.setText("");
    }

    private void fetchSponsorBlock() {
        final String id = videoId;
        io.execute(() -> {
            try {
                final List<PlaybackService.Seg> segs = SponsorBlock.fetch(id);
                runOnUiThread(() -> {
                    if (svc != null) svc.setSegments(segs);
                    status.setText("SponsorBlock: " + segs.size() + " فقرة");
                });
            } catch (Throwable e) {
                runOnUiThread(() -> status.setText("SponsorBlock غير متاح: " + e));
            }
        });
    }

    private void download(String url, String ext) {
        if (url == null) return;
        try {
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            String name = Fmt.safeName(title == null ? "video" : title) + ext;
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            r.setTitle(name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            dm.enqueue(r);
            Toast.makeText(this, "بدأ التحميل في مجلد Downloads", Toast.LENGTH_LONG).show();
        } catch (Throwable e) {
            Toast.makeText(this, "فشل التحميل: " + e, Toast.LENGTH_LONG).show();
        }
    }

    private void attach() {
        if (svc == null) return;
        view.setPlayer(svc.getPlayer());
        svc.setVideoEnabled(true);
    }

    @Override protected void onStart() {
        super.onStart();
        visible = true;
        attach();
    }

    @Override protected void onStop() {
        visible = false;
        view.setPlayer(null);
        if (svc != null) svc.setVideoEnabled(false);
        super.onStop();
    }

    @Override protected void onDestroy() {
        if (bound) unbindService(conn);
        io.shutdownNow();
        super.onDestroy();
    }
}
