package com.kitkat.tube;

import java.util.List;
import org.json.JSONObject;
import org.schabi.newpipe.extractor.Image;
import org.schabi.newpipe.extractor.stream.StreamInfoItem;

/** صف فيديو بسيط (للنتائج والمقترحات والسجل). */
final class Row {
    String url, title, uploader, thumb, meta, channelUrl;
    long duration;
    long ts;

    static Row from(StreamInfoItem it) {
        Row r = new Row();
        r.url = it.getUrl();
        r.title = it.getName();
        r.uploader = it.getUploaderName();
        r.duration = it.getDuration();
        r.channelUrl = it.getUploaderUrl();
        String views = Fmt.views(it.getViewCount());
        String date = it.getTextualUploadDate() == null ? "" : it.getTextualUploadDate();
        r.meta = views.isEmpty() ? date : (date.isEmpty() ? views : views + " • " + date);
        r.thumb = bestThumb(it.getThumbnails());
        return r;
    }

    static String bestThumb(List<Image> th) {
        Image best = null;
        for (Image i : th) {
            if (best == null || Math.abs(i.getWidth() - 400) < Math.abs(best.getWidth() - 400)) best = i;
        }
        return best == null ? null : best.getUrl();
    }

    JSONObject toJson() throws Exception {
        JSONObject o = new JSONObject();
        o.put("url", url);
        o.put("title", title);
        o.put("up", uploader);
        o.put("thumb", thumb);
        o.put("meta", meta);
        o.put("dur", duration);
        o.put("cu", channelUrl);
        o.put("cu", channelUrl);
        return o;
    }

    static Row fromJson(JSONObject o) {
        Row r = new Row();
        r.url = o.optString("url", null);
        r.title = o.optString("title", "");
        r.uploader = o.optString("up", "");
        r.thumb = o.isNull("thumb") ? null : o.optString("thumb", null);
        r.meta = o.optString("meta", "");
        r.duration = o.optLong("dur", 0);
        r.channelUrl = o.isNull("cu") ? null : o.optString("cu", null);
        r.channelUrl = o.isNull("cu") ? null : o.optString("cu", null);
        return r;
    }
}
