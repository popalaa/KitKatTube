package com.kitkat.tube;

import android.text.Html;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** آخر فيديوهات القناة من الـ RSS الرسمي (سريع وبدون حساب). */
final class Rss {
    private Rss() {}

    private static String find(String text, String regex) {
        Matcher m = Pattern.compile(regex).matcher(text);
        return m.find() ? m.group(1) : "";
    }

    static List<Row> fetch(String channelId) throws Exception {
        okhttp3.Request rq = new okhttp3.Request.Builder()
            .url("https://www.youtube.com/feeds/videos.xml?channel_id=" + channelId).build();
        okhttp3.Response r = HttpDownloader.client().newCall(rq).execute();
        String body;
        try {
            if (!r.isSuccessful()) throw new IOException("HTTP " + r.code());
            body = r.body().string();
        } finally {
            r.close();
        }
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
        df.setTimeZone(TimeZone.getTimeZone("UTC"));
        List<Row> out = new ArrayList<>();
        String[] parts = body.split("<entry>");
        for (int i = 1; i < parts.length; i++) {
            String e = parts[i];
            String id = find(e, "<yt:videoId>(.*?)</yt:videoId>");
            if (id.isEmpty()) continue;
            Row row = new Row();
            row.url = "https://www.youtube.com/watch?v=" + id;
            row.title = Html.fromHtml(find(e, "<title>(.*?)</title>")).toString();
            row.uploader = Html.fromHtml(find(e, "<name>(.*?)</name>")).toString();
            row.thumb = "https://i.ytimg.com/vi/" + id + "/mqdefault.jpg";
            row.channelUrl = "https://www.youtube.com/channel/" + channelId;
            String pub = find(e, "<published>(.*?)</published>");
            try { row.ts = df.parse(pub.substring(0, 19)).getTime(); } catch (Throwable ignored) { }
            String views = find(e, "<media:statistics views=\"(\\d+)\"");
            String v = views.isEmpty() ? "" : Fmt.views(Long.parseLong(views));
            String ago = Fmt.ago(row.ts);
            row.meta = v.isEmpty() ? ago : (ago.isEmpty() ? v : v + " • " + ago);
            out.add(row);
        }
        return out;
    }
}
