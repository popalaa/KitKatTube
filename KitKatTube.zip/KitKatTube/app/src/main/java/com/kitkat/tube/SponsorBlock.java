package com.kitkat.tube;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import okhttp3.HttpUrl;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

final class SponsorBlock {
    private SponsorBlock() {}

    static List<PlaybackService.Seg> fetch(String videoId) throws Exception {
        List<PlaybackService.Seg> out = new ArrayList<>();
        HttpUrl url = HttpUrl.parse("https://sponsor.ajay.app/api/skipSegments").newBuilder()
            .addQueryParameter("videoID", videoId)
            .addQueryParameter("categories",
                "[\"sponsor\",\"selfpromo\",\"interaction\",\"intro\",\"outro\",\"preview\"]")
            .build();
        Response r = HttpDownloader.client().newCall(new Request.Builder().url(url).build()).execute();
        try {
            if (r.code() == 404) return out;
            if (!r.isSuccessful()) throw new IOException("HTTP " + r.code());
            JSONArray arr = new JSONArray(r.body().string());
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                if (!"skip".equals(o.optString("actionType", "skip"))) continue;
                JSONArray seg = o.getJSONArray("segment");
                PlaybackService.Seg s = new PlaybackService.Seg();
                s.start = (long) (seg.getDouble(0) * 1000);
                s.end = (long) (seg.getDouble(1) * 1000);
                s.category = o.optString("category", "");
                out.add(s);
            }
        } finally {
            r.close();
        }
        return out;
    }
}
