package com.kitkat.tube;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONObject;

/** الاشتراكات (محفوظة محلياً على الجهاز). */
final class Subs {
    static class Chan {
        String id, url, name, avatar;
        Chan(String id, String url, String name, String avatar) {
            this.id = id; this.url = url; this.name = name; this.avatar = avatar;
        }
    }

    private static final Pattern ID = Pattern.compile("channel/(UC[A-Za-z0-9_-]{22})");

    private Subs() {}

    static String idFromUrl(String url) {
        if (url == null) return null;
        Matcher m = ID.matcher(url);
        return m.find() ? m.group(1) : null;
    }

    private static android.content.SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("subs", Context.MODE_PRIVATE);
    }

    static synchronized String signature(Context c) { return prefs(c).getString("list", "[]"); }

    static synchronized List<Chan> load(Context c) {
        List<Chan> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs(c).getString("list", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Chan(o.isNull("id") ? null : o.optString("id", null),
                    o.optString("url", ""), o.optString("name", ""),
                    o.isNull("av") ? null : o.optString("av", null)));
            }
        } catch (Throwable ignored) { }
        return out;
    }

    private static void save(Context c, List<Chan> list) {
        try {
            JSONArray a = new JSONArray();
            for (Chan ch : list) {
                JSONObject o = new JSONObject();
                o.put("id", ch.id);
                o.put("url", ch.url);
                o.put("name", ch.name);
                o.put("av", ch.avatar);
                a.put(o);
            }
            prefs(c).edit().putString("list", a.toString()).apply();
        } catch (Throwable ignored) { }
    }

    private static boolean same(Chan ch, String url) {
        String id = idFromUrl(url);
        if (id != null && id.equals(ch.id)) return true;
        return url != null && url.equals(ch.url);
    }

    static synchronized boolean contains(Context c, String url) {
        for (Chan ch : load(c)) if (same(ch, url)) return true;
        return false;
    }

    static synchronized void add(Context c, Chan ch) {
        List<Chan> list = load(c);
        for (Chan x : list) if (same(x, ch.url)) return;
        list.add(0, ch);
        save(c, list);
    }

    static synchronized void remove(Context c, String url) {
        List<Chan> list = load(c);
        for (int i = list.size() - 1; i >= 0; i--) if (same(list.get(i), url)) list.remove(i);
        save(c, list);
    }

    static synchronized void setAvatar(Context c, String url, String avatar) {
        if (avatar == null) return;
        List<Chan> list = load(c);
        boolean changed = false;
        for (Chan x : list) {
            if (same(x, url) && !avatar.equals(x.avatar)) { x.avatar = avatar; changed = true; }
        }
        if (changed) save(c, list);
    }
}
