package com.kitkat.tube;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/** يفعّل TLSv1.2 على API 19-20. */
public class Tls12SocketFactory extends SSLSocketFactory {
    private final SSLSocketFactory d;
    public Tls12SocketFactory(SSLSocketFactory d) { this.d = d; }
    private Socket fix(Socket s) {
        if (s instanceof SSLSocket) ((SSLSocket) s).setEnabledProtocols(new String[]{"TLSv1.1", "TLSv1.2"});
        return s;
    }
    @Override public String[] getDefaultCipherSuites() { return d.getDefaultCipherSuites(); }
    @Override public String[] getSupportedCipherSuites() { return d.getSupportedCipherSuites(); }
    @Override public Socket createSocket(Socket s, String h, int p, boolean a) throws IOException { return fix(d.createSocket(s, h, p, a)); }
    @Override public Socket createSocket(String h, int p) throws IOException { return fix(d.createSocket(h, p)); }
    @Override public Socket createSocket(String h, int p, InetAddress l, int lp) throws IOException { return fix(d.createSocket(h, p, l, lp)); }
    @Override public Socket createSocket(InetAddress h, int p) throws IOException { return fix(d.createSocket(h, p)); }
    @Override public Socket createSocket(InetAddress a, int p, InetAddress l, int lp) throws IOException { return fix(d.createSocket(a, p, l, lp)); }
}
