package com.kitkat.tube;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/** صفوف مدمجة (صورة على الشمال) للمقترحات. */
class VideoAdapter extends BaseAdapter {
    final List<Row> items = new ArrayList<>();
    private final LayoutInflater inflater;

    VideoAdapter(Context c) { inflater = LayoutInflater.from(c); }

    @Override public int getCount() { return items.size(); }
    @Override public Object getItem(int i) { return items.get(i); }
    @Override public long getItemId(int i) { return i; }

    @Override public View getView(int pos, View v, ViewGroup parent) {
        if (v == null) v = inflater.inflate(R.layout.item_video, parent, false);
        Row r = items.get(pos);
        ((TextView) v.findViewById(R.id.title)).setText(r.title);
        StringBuilder sub = new StringBuilder();
        if (r.uploader != null) sub.append(r.uploader);
        if (r.meta != null && !r.meta.isEmpty()) sub.append('\n').append(r.meta);
        ((TextView) v.findViewById(R.id.sub)).setText(sub);
        TextView dur = (TextView) v.findViewById(R.id.dur);
        dur.setText(Fmt.duration(r.duration));
        dur.setVisibility(r.duration > 0 ? View.VISIBLE : View.GONE);
        ImageLoader.load(r.thumb, (ImageView) v.findViewById(R.id.thumb));
        return v;
    }
}
