package com.kitkat.tube;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import org.schabi.newpipe.extractor.Image;
import org.schabi.newpipe.extractor.stream.StreamInfoItem;

class VideoAdapter extends BaseAdapter {
    final List<StreamInfoItem> items = new ArrayList<>();
    private final LayoutInflater inflater;

    VideoAdapter(Context c) { inflater = LayoutInflater.from(c); }

    @Override public int getCount() { return items.size(); }
    @Override public Object getItem(int i) { return items.get(i); }
    @Override public long getItemId(int i) { return i; }

    @Override public View getView(int pos, View v, ViewGroup parent) {
        if (v == null) v = inflater.inflate(R.layout.item_video, parent, false);
        StreamInfoItem it = items.get(pos);
        ((TextView) v.findViewById(R.id.title)).setText(it.getName());
        String views = Fmt.views(it.getViewCount());
        String date = it.getTextualUploadDate() == null ? "" : it.getTextualUploadDate();
        StringBuilder sub = new StringBuilder();
        if (it.getUploaderName() != null) sub.append(it.getUploaderName());
        String extra = views.isEmpty() ? date : (date.isEmpty() ? views : views + " • " + date);
        if (!extra.isEmpty()) sub.append('\n').append(extra);
        ((TextView) v.findViewById(R.id.sub)).setText(sub);
        ((TextView) v.findViewById(R.id.dur)).setText(Fmt.duration(it.getDuration()));
        v.findViewById(R.id.dur).setVisibility(it.getDuration() > 0 ? View.VISIBLE : View.GONE);
        ImageLoader.load(bestThumb(it), (ImageView) v.findViewById(R.id.thumb));
        return v;
    }

    private static String bestThumb(StreamInfoItem it) {
        Image best = null;
        for (Image i : it.getThumbnails()) {
            if (best == null || Math.abs(i.getWidth() - 320) < Math.abs(best.getWidth() - 320)) best = i;
        }
        return best == null ? null : best.getUrl();
    }
}
