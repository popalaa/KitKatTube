# KitKatTube (minSdk 19)
فتح المجلد في Android Studio (Flamingo أو أحدث) ثم Build > Build APK.
- بحث + تشغيل حتى 1080p (دمج فيديو+صوت) مع بديل muxed وHLS.
- TLS 1.2 مفعّل يدوياً لأندرويد 4.4 (للبحث والتشغيل).
- تشغيل في الخلفية (Service) + SponsorBlock.
- التالي: DASH لجودات أعلى.
- المكتبة المثبتة: NewPipeExtractor v0.26.5. لو فشلت في البناء: جرّب v0.24.2 أو v0.23.1.
